using System;
using System.Collections.Generic;
using System.Linq;
using RoomFinisher.Helpers;
using RoomFinisher.Models;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Services
{
    /// <summary>
    /// BIM quality-control engine. Scans the loaded rooms for duplicates, empty finishes, naming
    /// inconsistencies (case/spacing) and near-duplicate ("Marble"/"Marbel") finish values, then
    /// computes a quality score.
    /// </summary>
    public sealed class QualityCheckService
    {
        private static readonly RoomField[] FinishFields =
        {
            RoomField.WallFinish, RoomField.FloorFinish, RoomField.CeilingFinish, RoomField.BaseFinish
        };

        public QualityReport Run(IEnumerable<RoomViewModel> rooms)
        {
            var list = rooms?.ToList() ?? new List<RoomViewModel>();
            var report = new QualityReport();

            DetectDuplicateNumbers(list, report.Issues);
            DetectDuplicateNames(list, report.Issues);
            DetectEmptyFinishes(list, report.Issues);
            DetectNamingInconsistencies(list, report.Issues);
            DetectSimilarFinishes(list, report.Issues);

            report.ErrorCount = report.Issues.Count(i => i.Severity == IssueSeverity.Error);
            report.WarningCount = report.Issues.Count(i => i.Severity == IssueSeverity.Warning);

            // Quality Score = 100 - (errors * 5) - (warnings * 1), clamped to [0, 100].
            report.Score = Math.Max(0, 100 - report.ErrorCount * 5 - report.WarningCount * 1);

            return report;
        }

        // ---- Duplicate room numbers (Error) --------------------------------------------------
        private static void DetectDuplicateNumbers(List<RoomViewModel> rooms, List<QualityIssue> issues)
        {
            var groups = rooms
                .Where(r => !string.IsNullOrWhiteSpace(r.Number))
                .GroupBy(r => r.Number.Trim(), StringComparer.OrdinalIgnoreCase)
                .Where(g => g.Count() > 1);

            foreach (var g in groups)
            {
                foreach (var room in g)
                {
                    issues.Add(new QualityIssue
                    {
                        Severity = IssueSeverity.Error,
                        Issue = $"Duplicate room number '{g.Key}' appears {g.Count()} times.",
                        RoomNumber = room.Number,
                        Field = "Room Number",
                        ElementIdValue = room.ElementIdValue
                    });
                }
            }
        }

        // ---- Duplicate room names (Warning) --------------------------------------------------
        private static void DetectDuplicateNames(List<RoomViewModel> rooms, List<QualityIssue> issues)
        {
            var groups = rooms
                .Where(r => !string.IsNullOrWhiteSpace(r.Name))
                .GroupBy(r => r.Name.Trim(), StringComparer.OrdinalIgnoreCase)
                .Where(g => g.Count() > 1);

            foreach (var g in groups)
            {
                foreach (var room in g)
                {
                    issues.Add(new QualityIssue
                    {
                        Severity = IssueSeverity.Warning,
                        Issue = $"Room name '{g.Key}' appears {g.Count()} times.",
                        RoomNumber = room.Number,
                        Field = "Room Name",
                        ElementIdValue = room.ElementIdValue
                    });
                }
            }
        }

        // ---- Empty finishes (Warning) --------------------------------------------------------
        private static void DetectEmptyFinishes(List<RoomViewModel> rooms, List<QualityIssue> issues)
        {
            foreach (var room in rooms)
            {
                foreach (var field in FinishFields)
                {
                    if (string.IsNullOrWhiteSpace(room.GetFieldValue(field)))
                    {
                        issues.Add(new QualityIssue
                        {
                            Severity = IssueSeverity.Warning,
                            Issue = $"Missing {field.ToDisplayName()}.",
                            RoomNumber = room.Number,
                            Field = field.ToDisplayName(),
                            ElementIdValue = room.ElementIdValue
                        });
                    }
                }
            }
        }

        // ---- Naming inconsistencies: same finish, different case/spacing (Warning) ------------
        private static void DetectNamingInconsistencies(List<RoomViewModel> rooms, List<QualityIssue> issues)
        {
            // Count every raw finish value across all four finish fields.
            var rawCounts = AllFinishValues(rooms)
                .GroupBy(v => v)
                .ToDictionary(g => g.Key, g => g.Count(), StringComparer.Ordinal);

            // Group raw values whose normalized key matches (lowercase, whitespace removed).
            var byNormalized = rawCounts.Keys
                .GroupBy(Normalize)
                .Where(g => g.Count() > 1); // more than one raw spelling -> inconsistency

            foreach (var g in byNormalized)
            {
                // Recommend the most frequently used raw spelling as the standard.
                var standard = g.OrderByDescending(v => rawCounts[v]).First();
                var variants = string.Join(", ", g.Select(v => $"\"{v}\""));

                issues.Add(new QualityIssue
                {
                    Severity = IssueSeverity.Warning,
                    Issue = $"Inconsistent finish spelling: {variants}.",
                    Field = "Finish",
                    Suggestion = $"Standardize to \"{standard}\"."
                });
            }
        }

        // ---- Similar finishes: fuzzy near-duplicates like Marble/Marbel (Warning) -------------
        private static void DetectSimilarFinishes(List<RoomViewModel> rooms, List<QualityIssue> issues)
        {
            // One canonical representative per normalized group, to avoid re-flagging case/space
            // differences already covered above.
            var canonical = AllFinishValues(rooms)
                .GroupBy(Normalize)
                .Select(g => g.First())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            var reported = new HashSet<string>();

            for (int i = 0; i < canonical.Count; i++)
            {
                for (int j = i + 1; j < canonical.Count; j++)
                {
                    var a = canonical[i];
                    var b = canonical[j];
                    if (LevenshteinHelper.AreSimilar(a, b, 2))
                    {
                        var key = string.CompareOrdinal(a, b) < 0 ? a + "|" + b : b + "|" + a;
                        if (reported.Add(key))
                        {
                            issues.Add(new QualityIssue
                            {
                                Severity = IssueSeverity.Warning,
                                Issue = $"Possible duplicate finish values: \"{a}\" and \"{b}\".",
                                Field = "Finish",
                                Suggestion = "Verify these refer to the same finish."
                            });
                        }
                    }
                }
            }
        }

        // ---- Helpers -------------------------------------------------------------------------
        private static IEnumerable<string> AllFinishValues(IEnumerable<RoomViewModel> rooms)
        {
            foreach (var room in rooms)
            {
                foreach (var field in FinishFields)
                {
                    var v = room.GetFieldValue(field);
                    if (!string.IsNullOrWhiteSpace(v)) yield return v.Trim();
                }
            }
        }

        private static string Normalize(string value)
        {
            return new string((value ?? string.Empty)
                .ToLowerInvariant()
                .Where(c => !char.IsWhiteSpace(c))
                .ToArray());
        }
    }
}
