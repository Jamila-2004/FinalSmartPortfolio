using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using Microsoft.Win32;
using RoomFinisher.Helpers;
using RoomFinisher.Models;
using RoomFinisher.Revit;
using RoomFinisher.Services;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Views
{
    /// <summary>
    /// Concrete <see cref="IDialogService"/> living in the Views layer. Creates/owns the WPF windows
    /// and message boxes so the ViewModels never reference window types directly.
    /// </summary>
    public sealed class DialogService : IDialogService
    {
        private static Window Owner =>
            RevitContext.CurrentWindow != null && RevitContext.CurrentWindow.IsLoaded
                ? RevitContext.CurrentWindow
                : null;

        public void ShowInfo(string title, string message)
            => MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information);

        public void ShowError(string title, string message)
            => MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Error);

        public bool Confirm(string title, string message)
            => MessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;

        public bool ShowValidation(IList<ValidationIssue> issues)
        {
            // Detailed, sortable validation window (replaces the old plain message box).
            return ShowModal(new ValidationWindow(new ValidationViewModel(issues)));
        }

        public bool ShowReview(ReviewChangesViewModel viewModel)
            => ShowModal(new ReviewChangesWindow(viewModel));

        public bool ShowBulkEdit(BulkEditViewModel viewModel)
            => ShowModal(new BulkEditWindow(viewModel));

        public bool ShowApplyTemplate(ApplyTemplateViewModel viewModel)
            => ShowModal(new ApplyTemplateWindow(viewModel));

        public void ShowQualityReport(QualityReportViewModel viewModel)
            => ShowModal(new QualityReportWindow(viewModel));

        public bool ShowAiSuggestions(AiSuggestionsViewModel viewModel)
            => ShowModal(new AiSuggestionsWindow(viewModel));

        public bool ShowAiSettings(AiSettingsViewModel viewModel)
            => ShowModal(new AiSettingsWindow(viewModel));

        public void ShowAnalytics(AnalyticsViewModel viewModel)
        {
            // Modeless so the user can keep editing and watch the charts update live.
            var window = new AnalyticsWindow(viewModel);
            if (Owner != null) window.Owner = Owner;
            window.Show();
        }

        public string OpenFile(string filter, string initialDirectory)
        {
            var dlg = new OpenFileDialog { Filter = filter, CheckFileExists = true };
            if (!string.IsNullOrEmpty(initialDirectory)) dlg.InitialDirectory = initialDirectory;
            return dlg.ShowDialog(Owner) == true ? dlg.FileName : null;
        }

        public string SaveFile(string filter, string defaultFileName, string initialDirectory)
        {
            var dlg = new SaveFileDialog { Filter = filter, FileName = defaultFileName, OverwritePrompt = true };
            if (!string.IsNullOrEmpty(initialDirectory)) dlg.InitialDirectory = initialDirectory;
            return dlg.ShowDialog(Owner) == true ? dlg.FileName : null;
        }

        private static bool ShowModal(Window window)
        {
            if (Owner != null) window.Owner = Owner;
            return window.ShowDialog() == true;
        }
    }
}
