using System;
using System.Collections.Generic;
using RoomFinisher.Models;

namespace RoomFinisher.Services
{
    /// <summary>
    /// API-free abstraction the ViewModel uses to talk to Revit. Because the window is MODELESS,
    /// the implementation marshals every call onto Revit's thread via an ExternalEvent and posts
    /// the result back on the UI dispatcher. The ViewModel therefore never touches the Revit API
    /// directly and stays unit-testable.
    /// </summary>
    public interface IRevitWorker
    {
        /// <summary>True while a Revit request is in flight (used to disable buttons).</summary>
        bool IsBusy { get; }

        /// <summary>Re-reads all rooms from the model. Callbacks fire on the UI thread.</summary>
        void CollectRooms(Action<IList<RoomData>> onDone, Action<string> onError);

        /// <summary>Commits all changes in a single transaction. Callbacks fire on the UI thread.</summary>
        void ApplyChanges(IList<RoomChangeSet> changes, Action<CommitResult> onDone, Action<string> onError);

        /// <summary>
        /// Selects the given rooms in Revit and zooms the active view to them ("Show in Revit").
        /// Callbacks fire on the UI thread.
        /// </summary>
        void ShowInRevit(IList<long> elementIdValues, Action onDone, Action<string> onError);
    }
}
