using System;

namespace RoomFinisher.Models
{
    /// <summary>
    /// A reusable set of finish assignments saved to / loaded from JSON
    /// (e.g. Office_Template.json). Serialized with System.Text.Json.
    /// </summary>
    public sealed class FinishTemplate
    {
        public string Name { get; set; } = "New Template";

        public string WallFinish { get; set; } = string.Empty;
        public string FloorFinish { get; set; } = string.Empty;
        public string CeilingFinish { get; set; } = string.Empty;
        public string BaseFinish { get; set; } = string.Empty;

        /// <summary>Display-unit ceiling height string. May be empty to leave ceiling height untouched.</summary>
        public string CeilingHeight { get; set; } = string.Empty;

        public string CreatedBy { get; set; } = Environment.UserName;
        public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;

        /// <summary>Schema version so future readers can migrate older files.</summary>
        public int Version { get; set; } = 1;
    }
}
