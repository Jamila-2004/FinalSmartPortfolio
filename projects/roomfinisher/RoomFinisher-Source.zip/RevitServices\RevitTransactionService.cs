using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using RoomFinisher.Models;

namespace RoomFinisher.RevitServices
{
    /// <summary>
    /// Writes all pending changes back to Revit inside ONE transaction. Runs only on the Revit
    /// thread (invoked from the ExternalEvent handler). Each room/parameter is wrapped in its own
    /// try/catch so a single bad value is reported as a per-room failure instead of crashing or
    /// rolling back everyone else's edits.
    /// </summary>
    public sealed class RevitTransactionService
    {
        public CommitResult Apply(Document doc, IList<RoomChangeSet> changes, AppSettings settings)
        {
            var result = new CommitResult();
            if (doc == null)
            {
                result.FatalError = "No active document.";
                return result;
            }
            if (changes == null || changes.Count == 0)
            {
                result.TransactionCommitted = true;
                return result;
            }

            using (var tx = new Transaction(doc, "Room Finisher: Apply Finishes"))
            {
                try
                {
                    tx.Start();

                    foreach (var change in changes)
                    {
                        var element = doc.GetElement(new ElementId(change.ElementIdValue));

                        // Handle rooms deleted since they were read into the grid.
                        if (!(element is Room room))
                        {
                            result.Failures.Add(new RoomFailure
                            {
                                RoomNumber = change.RoomNumber,
                                RoomName = change.RoomName,
                                Reason = "Room no longer exists in the model (it may have been deleted)."
                            });
                            continue;
                        }

                        var fieldErrors = new List<string>();

                        foreach (var kv in change.ChangedFields)
                        {
                            try
                            {
                                RoomParameterService.SetField(room, kv.Key, kv.Value,
                                    settings.CeilingHeightParameterName);
                            }
                            catch (Exception ex)
                            {
                                // Read-only param, invalid value, missing shared param, etc.
                                fieldErrors.Add($"{kv.Key.ToDisplayName()} - {ex.Message}");
                            }
                        }

                        if (fieldErrors.Count == 0)
                        {
                            result.Updated++;
                        }
                        else
                        {
                            result.Failures.Add(new RoomFailure
                            {
                                RoomNumber = change.RoomNumber,
                                RoomName = change.RoomName,
                                Reason = string.Join("; ", fieldErrors)
                            });
                        }
                    }

                    tx.Commit();
                    result.TransactionCommitted = true;
                }
                catch (Exception ex)
                {
                    // Catastrophic failure -> roll back so the model is left untouched.
                    if (tx.GetStatus() == TransactionStatus.Started)
                    {
                        tx.RollBack();
                    }
                    result.TransactionCommitted = false;
                    result.FatalError = ex.Message;
                }
            }

            return result;
        }
    }
}
