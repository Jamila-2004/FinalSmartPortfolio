using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// Minimal INotifyPropertyChanged base class for all ViewModels. Provides RaisePropertyChanged
    /// and a SetProperty helper so derived classes stay terse.
    /// </summary>
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>Sets a backing field and raises PropertyChanged when the value actually changes.</summary>
        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            if (Equals(field, value)) return false;
            field = value;
            RaisePropertyChanged(propertyName);
            return true;
        }
    }
}
