using System.Windows;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Views
{
    /// <summary>Quality Report dialog. Code-behind only forwards the close request.</summary>
    public partial class QualityReportWindow : Window
    {
        public QualityReportWindow(QualityReportViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
            viewModel.RequestClose += result =>
            {
                DialogResult = result;
                Close();
            };
        }
    }
}
