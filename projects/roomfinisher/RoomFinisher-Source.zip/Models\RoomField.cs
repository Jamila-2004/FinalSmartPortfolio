using System;
using System.Collections.Generic;

namespace RoomFinisher.Models
{
    /// <summary>
    /// Strongly-typed identifier for every editable room field. Using an enum (instead of
    /// magic strings) lets the change-tracking, bulk-edit, undo and Revit-write layers all
    /// agree on exactly which parameter is being touched.
    /// </summary>
    public enum RoomField
    {
        Number,
        Name,
        Level,        // read-only (display only)
        Department,
        WallFinish,
        FloorFinish,
        CeilingFinish,
        BaseFinish,
        CeilingHeight
    }

    /// <summary>Helpers for presenting <see cref="RoomField"/> values to the user.</summary>
    public static class RoomFieldExtensions
    {
        private static readonly Dictionary<RoomField, string> DisplayNames = new Dictionary<RoomField, string>
        {
            { RoomField.Number,        "Room Number" },
            { RoomField.Name,          "Room Name" },
            { RoomField.Level,         "Level" },
            { RoomField.Department,    "Department" },
            { RoomField.WallFinish,    "Wall Finish" },
            { RoomField.FloorFinish,   "Floor Finish" },
            { RoomField.CeilingFinish, "Ceiling Finish" },
            { RoomField.BaseFinish,    "Base Finish" },
            { RoomField.CeilingHeight, "Ceiling Height" },
        };

        /// <summary>Human-readable column/parameter name, e.g. RoomField.WallFinish -> "Wall Finish".</summary>
        public static string ToDisplayName(this RoomField field)
        {
            return DisplayNames.TryGetValue(field, out var name) ? name : field.ToString();
        }

        /// <summary>True for fields that participate in finish analytics / quality checks.</summary>
        public static bool IsFinishField(this RoomField field)
        {
            return field == RoomField.WallFinish
                || field == RoomField.FloorFinish
                || field == RoomField.CeilingFinish
                || field == RoomField.BaseFinish;
        }
    }
}
