using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;
using System.Windows.Input;
using RoomFinisher.Helpers;
using RoomFinisher.Models;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// Backs the Review Changes window shown before committing. Lists every pending parameter change
    /// (room, parameter, original, new) with search + sortable columns, and the confirm/back/cancel
    /// actions. Only "Confirm Apply" returns true (which triggers the Revit transaction).
    /// </summary>
    public sealed class ReviewChangesViewModel : ViewModelBase
    {
        private readonly ObservableCollection<ChangeRecord> _all;
        private readonly ICollectionView _view;
        private string _searchText = string.Empty;

        public ReviewChangesViewModel(IEnumerable<ChangeRecord> records)
        {
            _all = new ObservableCollection<ChangeRecord>(records ?? Enumerable.Empty<ChangeRecord>());
            _view = CollectionViewSource.GetDefaultView(_all);
            _view.Filter = Filter;

            ConfirmCommand = new RelayCommand(() => RequestClose?.Invoke(true), () => _all.Count > 0);
            BackCommand = new RelayCommand(() => RequestClose?.Invoke(false));
            CancelCommand = new RelayCommand(() => RequestClose?.Invoke(false));
        }

        /// <summary>true = Confirm Apply, false = Back/Cancel.</summary>
        public event Action<bool> RequestClose;

        public ICollectionView Changes => _view;

        public string SearchText
        {
            get => _searchText;
            set { if (SetProperty(ref _searchText, value)) _view.Refresh(); }
        }

        public int ParameterChangeCount => _all.Count;

        public int RoomsModifiedCount =>
            _all.Select(r => r.RoomNumber).Distinct(StringComparer.OrdinalIgnoreCase).Count();

        public string FooterSummary =>
            $"Rooms Modified: {RoomsModifiedCount}    Parameter Changes: {ParameterChangeCount}";

        public ICommand ConfirmCommand { get; }
        public ICommand BackCommand { get; }
        public ICommand CancelCommand { get; }

        private bool Filter(object obj)
        {
            if (string.IsNullOrWhiteSpace(_searchText)) return true;
            if (!(obj is ChangeRecord r)) return false;

            var t = _searchText.Trim();
            return Has(r.RoomNumber, t) || Has(r.RoomName, t) || Has(r.Parameter, t)
                || Has(r.OriginalValue, t) || Has(r.NewValue, t);
        }

        private static bool Has(string value, string text)
            => !string.IsNullOrEmpty(value) && value.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0;
    }
}
