using System;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// One checkable level in the multi-select level filter. Toggling it notifies the MainViewModel
    /// (via the supplied callback) so the grid re-filters. Selecting none means "all levels".
    /// </summary>
    public sealed class LevelFilterItem : ViewModelBase
    {
        private readonly Action _onChanged;
        private bool _isSelected;

        public LevelFilterItem(string name, Action onChanged)
        {
            Name = name;
            _onChanged = onChanged;
        }

        public string Name { get; }

        public bool IsSelected
        {
            get => _isSelected;
            set { if (SetProperty(ref _isSelected, value)) _onChanged?.Invoke(); }
        }
    }
}
