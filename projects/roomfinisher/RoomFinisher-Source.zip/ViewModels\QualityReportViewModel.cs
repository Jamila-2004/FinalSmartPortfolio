using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows.Input;
using RoomFinisher.Helpers;
using RoomFinisher.Models;
using RoomFinisher.Services;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// Backs the Quality Report window: the list of issues, the summary counts and quality score,
    /// and the Export / Fix Selected / Close actions.
    /// </summary>
    public sealed class QualityReportViewModel : ViewModelBase
    {
        private readonly ExcelExportService _excel;
        private readonly IDialogService _dialogs;
        private readonly Action<long> _focusRoom;
        private QualityIssue _selectedIssue;

        public QualityReportViewModel(QualityReport report, ExcelExportService excel, IDialogService dialogs, Action<long> focusRoom)
        {
            _excel = excel;
            _dialogs = dialogs;
            _focusRoom = focusRoom;

            Issues = new ObservableCollection<QualityIssue>(report.Issues);
            ErrorCount = report.ErrorCount;
            WarningCount = report.WarningCount;
            Score = report.Score;

            ExportReportCommand = new RelayCommand(ExportReport, () => Issues.Count > 0);
            FixSelectedCommand = new RelayCommand(FixSelected, () => SelectedIssue != null && SelectedIssue.ElementIdValue != 0);
            CloseCommand = new RelayCommand(() => RequestClose?.Invoke(false));
        }

        /// <summary>Raised to close the window. true = jumped to a room via Fix Selected.</summary>
        public event Action<bool> RequestClose;

        public ObservableCollection<QualityIssue> Issues { get; }

        public QualityIssue SelectedIssue
        {
            get => _selectedIssue;
            set => SetProperty(ref _selectedIssue, value);
        }

        public int ErrorCount { get; }
        public int WarningCount { get; }
        public int Score { get; }

        public string Summary => $"Errors: {ErrorCount}    Warnings: {WarningCount}    Quality Score: {Score}%";

        public ICommand ExportReportCommand { get; }
        public ICommand FixSelectedCommand { get; }
        public ICommand CloseCommand { get; }

        private void ExportReport()
        {
            var path = _dialogs.SaveFile(
                "CSV (*.csv)|*.csv|Excel Workbook (*.xlsx)|*.xlsx",
                "Quality_Report.csv",
                string.Empty);

            if (string.IsNullOrEmpty(path)) return;

            try
            {
                int count;
                if (path.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase))
                    count = _excel.ExportQualityIssues(Issues, path);
                else
                    count = _excel.ExportQualityIssuesCsv(Issues, path);

                _dialogs.ShowInfo("Report Exported", $"{count} issues exported to:\n{path}");
            }
            catch (UnauthorizedAccessException)
            {
                _dialogs.ShowError("Export Failed", $"You do not have permission to write to:\n{path}");
            }
            catch (IOException ex)
            {
                _dialogs.ShowError("Export Failed",
                    $"The file may be open in another program:\n{path}\n\nDetails: {ex.Message}");
            }
            catch (Exception ex)
            {
                _dialogs.ShowError("Export Failed", ex.Message);
            }
        }

        private void FixSelected()
        {
            if (SelectedIssue == null || SelectedIssue.ElementIdValue == 0) return;
            _focusRoom?.Invoke(SelectedIssue.ElementIdValue);
            RequestClose?.Invoke(true);
        }
    }
}
