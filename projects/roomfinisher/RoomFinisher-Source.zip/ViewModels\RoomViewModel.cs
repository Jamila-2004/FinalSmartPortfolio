using System;
using RoomFinisher.Models;
using RoomFinisher.Services;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// Editable wrapper around one room. Holds the immutable original snapshot for dirty-tracking
    /// and routes every change through <see cref="Set"/> so highlighting, the modified count and
    /// Undo all stay consistent. No Revit API references - this is pure UI state.
    /// </summary>
    public sealed class RoomViewModel : ViewModelBase
    {
        private RoomData _original;
        private readonly UndoService _undo;
        private readonly FinishOptionsProvider _options;

        // Set true while an Undo restore is being applied so we don't record a new undo entry.
        private bool _suppressUndo;

        private string _number;
        private string _name;
        private string _department;
        private string _wallFinish;
        private string _floorFinish;
        private string _ceilingFinish;
        private string _baseFinish;
        private string _ceilingHeight;

        public RoomViewModel(RoomData original, UndoService undo, FinishOptionsProvider options)
        {
            _original = original ?? new RoomData();
            _undo = undo;
            _options = options;

            _number = _original.Number ?? string.Empty;
            _name = _original.Name ?? string.Empty;
            _department = _original.Department ?? string.Empty;
            _wallFinish = _original.WallFinish ?? string.Empty;
            _floorFinish = _original.FloorFinish ?? string.Empty;
            _ceilingFinish = _original.CeilingFinish ?? string.Empty;
            _baseFinish = _original.BaseFinish ?? string.Empty;
            _ceilingHeight = _original.CeilingHeight ?? string.Empty;
        }

        /// <summary>Raised whenever any field's value (and thus the modified state) changes.</summary>
        public event EventHandler ModifiedStateChanged;

        // ---- Identity / read-only ------------------------------------------------------------
        public long ElementIdValue => _original.ElementIdValue;
        public string Level => _original.Level;
        public bool IsPlaced => _original.IsPlaced;
        public bool CeilingHeightSupported => _original.CeilingHeightSupported;

        // ---- Editable properties -------------------------------------------------------------
        public string Number
        {
            get => _number;
            set => Set(RoomField.Number, ref _number, value, nameof(Number), nameof(IsNumberModified));
        }

        public string Name
        {
            get => _name;
            set => Set(RoomField.Name, ref _name, value, nameof(Name), nameof(IsNameModified));
        }

        public string Department
        {
            get => _department;
            set => Set(RoomField.Department, ref _department, value, nameof(Department), nameof(IsDepartmentModified));
        }

        public string WallFinish
        {
            get => _wallFinish;
            set => Set(RoomField.WallFinish, ref _wallFinish, value, nameof(WallFinish), nameof(IsWallFinishModified));
        }

        public string FloorFinish
        {
            get => _floorFinish;
            set => Set(RoomField.FloorFinish, ref _floorFinish, value, nameof(FloorFinish), nameof(IsFloorFinishModified));
        }

        public string CeilingFinish
        {
            get => _ceilingFinish;
            set => Set(RoomField.CeilingFinish, ref _ceilingFinish, value, nameof(CeilingFinish), nameof(IsCeilingFinishModified));
        }

        public string BaseFinish
        {
            get => _baseFinish;
            set => Set(RoomField.BaseFinish, ref _baseFinish, value, nameof(BaseFinish), nameof(IsBaseFinishModified));
        }

        public string CeilingHeight
        {
            get => _ceilingHeight;
            set => Set(RoomField.CeilingHeight, ref _ceilingHeight, value, nameof(CeilingHeight), nameof(IsCeilingHeightModified));
        }

        // ---- Per-field modified flags (bound by the grid cell styles for yellow highlight) ----
        public bool IsNumberModified => Differs(_number, _original.Number);
        public bool IsNameModified => Differs(_name, _original.Name);
        public bool IsDepartmentModified => Differs(_department, _original.Department);
        public bool IsWallFinishModified => Differs(_wallFinish, _original.WallFinish);
        public bool IsFloorFinishModified => Differs(_floorFinish, _original.FloorFinish);
        public bool IsCeilingFinishModified => Differs(_ceilingFinish, _original.CeilingFinish);
        public bool IsBaseFinishModified => Differs(_baseFinish, _original.BaseFinish);
        public bool IsCeilingHeightModified => Differs(_ceilingHeight, _original.CeilingHeight);

        /// <summary>True when any editable field differs from its original value.</summary>
        public bool IsModified =>
            IsNumberModified || IsNameModified || IsDepartmentModified ||
            IsWallFinishModified || IsFloorFinishModified || IsCeilingFinishModified ||
            IsBaseFinishModified || IsCeilingHeightModified;

        // ---- Field access by enum (used by services) -----------------------------------------
        public string GetFieldValue(RoomField field)
        {
            switch (field)
            {
                case RoomField.Number: return _number;
                case RoomField.Name: return _name;
                case RoomField.Level: return Level;
                case RoomField.Department: return _department;
                case RoomField.WallFinish: return _wallFinish;
                case RoomField.FloorFinish: return _floorFinish;
                case RoomField.CeilingFinish: return _ceilingFinish;
                case RoomField.BaseFinish: return _baseFinish;
                case RoomField.CeilingHeight: return _ceilingHeight;
                default: return string.Empty;
            }
        }

        public string GetOriginalValue(RoomField field)
        {
            switch (field)
            {
                case RoomField.Number: return _original.Number;
                case RoomField.Name: return _original.Name;
                case RoomField.Level: return _original.Level;
                case RoomField.Department: return _original.Department;
                case RoomField.WallFinish: return _original.WallFinish;
                case RoomField.FloorFinish: return _original.FloorFinish;
                case RoomField.CeilingFinish: return _original.CeilingFinish;
                case RoomField.BaseFinish: return _original.BaseFinish;
                case RoomField.CeilingHeight: return _original.CeilingHeight;
                default: return string.Empty;
            }
        }

        public bool IsFieldModified(RoomField field)
        {
            switch (field)
            {
                case RoomField.Number: return IsNumberModified;
                case RoomField.Name: return IsNameModified;
                case RoomField.Department: return IsDepartmentModified;
                case RoomField.WallFinish: return IsWallFinishModified;
                case RoomField.FloorFinish: return IsFloorFinishModified;
                case RoomField.CeilingFinish: return IsCeilingFinishModified;
                case RoomField.BaseFinish: return IsBaseFinishModified;
                case RoomField.CeilingHeight: return IsCeilingHeightModified;
                default: return false;
            }
        }

        /// <summary>Sets a field (records Undo). Used by bulk edit / template apply.</summary>
        public void SetFieldValue(RoomField field, string value)
        {
            switch (field)
            {
                case RoomField.Number: Number = value; break;
                case RoomField.Name: Name = value; break;
                case RoomField.Department: Department = value; break;
                case RoomField.WallFinish: WallFinish = value; break;
                case RoomField.FloorFinish: FloorFinish = value; break;
                case RoomField.CeilingFinish: CeilingFinish = value; break;
                case RoomField.BaseFinish: BaseFinish = value; break;
                case RoomField.CeilingHeight: CeilingHeight = value; break;
            }
        }

        /// <summary>Restores a field during Undo without recording a new undo entry.</summary>
        public void RestoreFieldValue(RoomField field, string value)
        {
            _suppressUndo = true;
            try { SetFieldValue(field, value); }
            finally { _suppressUndo = false; }
        }

        /// <summary>Reverts all fields to their original values (used by the row context action).</summary>
        public void Revert()
        {
            _suppressUndo = true;
            try
            {
                Number = _original.Number;
                Name = _original.Name;
                Department = _original.Department;
                WallFinish = _original.WallFinish;
                FloorFinish = _original.FloorFinish;
                CeilingFinish = _original.CeilingFinish;
                BaseFinish = _original.BaseFinish;
                CeilingHeight = _original.CeilingHeight;
            }
            finally { _suppressUndo = false; }
        }

        /// <summary>
        /// After a successful commit, makes the current values the new baseline so the modified
        /// highlighting clears without needing to re-read the model.
        /// </summary>
        public void AcceptAsBaseline()
        {
            _original = new RoomData
            {
                ElementIdValue = _original.ElementIdValue,
                Level = _original.Level,
                IsPlaced = _original.IsPlaced,
                CeilingHeightSupported = _original.CeilingHeightSupported,
                Number = _number,
                Name = _name,
                Department = _department,
                WallFinish = _wallFinish,
                FloorFinish = _floorFinish,
                CeilingFinish = _ceilingFinish,
                BaseFinish = _baseFinish,
                CeilingHeight = _ceilingHeight
            };
            RaiseAllModifiedFlags();
        }

        // ---- Internals -----------------------------------------------------------------------
        private void Set(RoomField field, ref string backing, string value, string propName, string modifiedPropName)
        {
            var newValue = value ?? string.Empty;
            if (string.Equals(backing, newValue, StringComparison.Ordinal)) return;

            var oldValue = backing;
            backing = newValue;

            if (!_suppressUndo)
            {
                _undo?.Record(this, field, oldValue, newValue);
                _options?.AddIfMissing(field, newValue);
            }

            RaisePropertyChanged(propName);
            RaisePropertyChanged(modifiedPropName);
            RaisePropertyChanged(nameof(IsModified));
            ModifiedStateChanged?.Invoke(this, EventArgs.Empty);
        }

        private static bool Differs(string current, string original)
        {
            return !string.Equals(current ?? string.Empty, original ?? string.Empty, StringComparison.Ordinal);
        }

        private void RaiseAllModifiedFlags()
        {
            RaisePropertyChanged(nameof(IsNumberModified));
            RaisePropertyChanged(nameof(IsNameModified));
            RaisePropertyChanged(nameof(IsDepartmentModified));
            RaisePropertyChanged(nameof(IsWallFinishModified));
            RaisePropertyChanged(nameof(IsFloorFinishModified));
            RaisePropertyChanged(nameof(IsCeilingFinishModified));
            RaisePropertyChanged(nameof(IsBaseFinishModified));
            RaisePropertyChanged(nameof(IsCeilingHeightModified));
            RaisePropertyChanged(nameof(IsModified));
            ModifiedStateChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}
