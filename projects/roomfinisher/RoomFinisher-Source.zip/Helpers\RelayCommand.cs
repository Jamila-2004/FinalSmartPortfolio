using System;
using System.Windows.Input;

namespace RoomFinisher.Helpers
{
    /// <summary>
    /// Standard MVVM <see cref="ICommand"/> implementation. Lets ViewModels expose button actions
    /// without any code-behind. Uses CommandManager.RequerySuggested so WPF re-evaluates CanExecute
    /// automatically (e.g. when focus or selection changes).
    /// </summary>
    public class RelayCommand : ICommand
    {
        private readonly Action _execute;
        private readonly Func<bool> _canExecute;

        public RelayCommand(Action execute, Func<bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter) => _canExecute == null || _canExecute();

        public void Execute(object parameter) => _execute();

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }

    /// <summary>Generic variant that receives a typed command parameter (e.g. the selected items list).</summary>
    public class RelayCommand<T> : ICommand
    {
        private readonly Action<T> _execute;
        private readonly Predicate<T> _canExecute;

        public RelayCommand(Action<T> execute, Predicate<T> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            if (_canExecute == null) return true;
            return _canExecute(Cast(parameter));
        }

        public void Execute(object parameter) => _execute(Cast(parameter));

        private static T Cast(object parameter)
        {
            return parameter is T t ? t : default;
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }
}
