using System;
using System.IO;
using RoomFinisher.Models;

namespace RoomFinisher.Services
{
    /// <summary>
    /// Append-only audit log of commits, written to %APPDATA%\RoomFinisher\audit.log. Best-effort:
    /// logging failures never interrupt the user's workflow.
    /// </summary>
    public sealed class AuditLogService
    {
        private static string LogDirectory =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "RoomFinisher");

        private static string LogPath => Path.Combine(LogDirectory, "audit.log");

        /// <summary>Writes a single timestamped line.</summary>
        public void Log(string message)
        {
            try
            {
                Directory.CreateDirectory(LogDirectory);
                File.AppendAllText(LogPath, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}\t{message}{Environment.NewLine}");
            }
            catch
            {
                // Audit logging is non-critical.
            }
        }

        /// <summary>Records the outcome of a commit, including per-room failures.</summary>
        public void LogCommit(string documentTitle, CommitResult result)
        {
            Log($"COMMIT doc=\"{documentTitle}\" user={Environment.UserName} " +
                $"updated={result.Updated} failed={result.Failed} committed={result.TransactionCommitted}");

            foreach (var failure in result.Failures)
            {
                Log($"  FAILED room={failure.RoomNumber} ({failure.RoomName}): {failure.Reason}");
            }

            if (!string.IsNullOrEmpty(result.FatalError))
            {
                Log($"  FATAL: {result.FatalError}");
            }
        }
    }
}
