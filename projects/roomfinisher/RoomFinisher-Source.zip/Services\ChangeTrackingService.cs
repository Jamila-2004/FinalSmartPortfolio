using System.Collections.Generic;
using RoomFinisher.Models;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Services
{
    /// <summary>
    /// Turns the set of modified rooms into (a) human-readable <see cref="ChangeRecord"/> rows for
    /// the Review window and (b) compact <see cref="RoomChangeSet"/> objects for the commit
    /// transaction. Both are derived from each room's per-field "modified" comparison against its
    /// original snapshot.
    /// </summary>
    public sealed class ChangeTrackingService
    {
        // Fields that can be edited and therefore committed (Level is read-only).
        private static readonly RoomField[] EditableFields =
        {
            RoomField.Number,
            RoomField.Name,
            RoomField.Department,
            RoomField.WallFinish,
            RoomField.FloorFinish,
            RoomField.CeilingFinish,
            RoomField.BaseFinish,
            RoomField.CeilingHeight
        };

        /// <summary>Builds one ChangeRecord per modified parameter (for the Review Changes grid).</summary>
        public List<ChangeRecord> BuildChangeRecords(IEnumerable<RoomViewModel> rooms)
        {
            var records = new List<ChangeRecord>();
            foreach (var room in rooms)
            {
                if (!room.IsModified) continue;
                foreach (var field in EditableFields)
                {
                    if (!room.IsFieldModified(field)) continue;
                    records.Add(new ChangeRecord
                    {
                        RoomNumber = room.Number,
                        RoomName = room.Name,
                        Parameter = field.ToDisplayName(),
                        OriginalValue = room.GetOriginalValue(field),
                        NewValue = room.GetFieldValue(field)
                    });
                }
            }
            return records;
        }

        /// <summary>Builds the minimal change sets to send to Revit (placed + modified rooms only).</summary>
        public List<RoomChangeSet> BuildChangeSets(IEnumerable<RoomViewModel> rooms)
        {
            var sets = new List<RoomChangeSet>();
            foreach (var room in rooms)
            {
                if (!room.IsModified) continue;

                // NOTE: We intentionally do NOT skip "unplaced" rooms here. Finish/department/name/
                // number are plain text parameters that are writable on any room regardless of
                // placement, so excluding unplaced rooms would wrongly block legitimate edits.

                var set = new RoomChangeSet
                {
                    ElementIdValue = room.ElementIdValue,
                    RoomNumber = room.Number,
                    RoomName = room.Name
                };

                foreach (var field in EditableFields)
                {
                    if (room.IsFieldModified(field))
                    {
                        set.ChangedFields[field] = room.GetFieldValue(field);
                    }
                }

                if (set.ChangedFields.Count > 0) sets.Add(set);
            }
            return sets;
        }
    }
}
