using System.Collections.Generic;
using RoomFinisher.Models;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Services
{
    /// <summary>
    /// Applies a single finish value to many rooms at once. Each set goes through
    /// <see cref="RoomViewModel.SetFieldValue"/> so dirty-tracking, highlighting and Undo all work
    /// exactly as if the user had typed each cell individually.
    /// </summary>
    public sealed class BulkEditService
    {
        /// <summary>
        /// Sets <paramref name="field"/> = <paramref name="value"/> on every room in
        /// <paramref name="rooms"/>. Returns the number of rooms actually changed.
        /// </summary>
        public int Apply(RoomField field, string value, IEnumerable<RoomViewModel> rooms)
        {
            int count = 0;
            foreach (var room in rooms)
            {
                // Skip ceiling height on rooms that don't support the parameter.
                if (field == RoomField.CeilingHeight && !room.CeilingHeightSupported) continue;

                room.SetFieldValue(field, value);
                count++;
            }
            return count;
        }
    }
}
