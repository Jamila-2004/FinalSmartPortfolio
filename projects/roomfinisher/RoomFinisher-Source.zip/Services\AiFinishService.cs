using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using RoomFinisher.Models;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Services
{
    /// <summary>
    /// AI Finish Assistant. Calls either Google Gemini or Anthropic Claude directly with HttpClient
    /// (no SDK, to avoid loading extra assemblies into Revit's shared AppDomain) and returns finish
    /// suggestions + design-suitability reasoning. Output is constrained to JSON, so parsing cannot
    /// break on free-form prose.
    ///
    /// Nothing is ever written to the model here - this only produces *suggestions*. The user approves
    /// them in a dialog, after which they flow through the normal Review + commit pipeline.
    /// </summary>
    public sealed class AiFinishService
    {
        private const string AnthropicEndpoint = "https://api.anthropic.com/v1/messages";
        private const string AnthropicVersion = "2023-06-01";
        private const string GeminiEndpointFormat =
            "https://generativelanguage.googleapis.com/v1beta/models/{0}:generateContent";

        private static readonly HttpClient Http = new HttpClient { Timeout = TimeSpan.FromSeconds(120) };

        // The JSON shape is described here so the prompt is self-sufficient on Gemini (which is given
        // a JSON mime type but not a provider-specific schema). On Anthropic we additionally enforce
        // it with output_config.format.
        private const string SystemPrompt =
            "You are an expert architectural finishes consultant helping complete a Revit room finish " +
            "schedule. For each room you are given its number, name, department, level and current " +
            "Wall/Floor/Ceiling/Base finishes (some may be empty). You are also given the project's " +
            "existing finish palette.\n\n" +
            "Your job:\n" +
            "1) Fill EMPTY finishes with values appropriate to the room's function.\n" +
            "2) Flag and replace EXISTING finishes that are unsuitable for the room's function, " +
            "considering hygiene, moisture, durability, traffic, acoustics and accessibility/code " +
            "(e.g. carpet in a wet area, no skirting in a corridor, slippery floors on ramps).\n" +
            "Prefer values already present in the project palette so the schedule stays consistent; " +
            "only introduce a new value when clearly necessary. Only suggest a change when the " +
            "suggested value differs from the current value. Keep each 'reason' under ~12 words. " +
            "Do not suggest Ceiling Height unless 'ceiling_supported' is true.\n\n" +
            "Respond ONLY with a JSON object of this exact shape (no extra text):\n" +
            "{\"changes\":[{\"id\":\"<room id>\",\"field\":\"WallFinish|FloorFinish|CeilingFinish|BaseFinish|CeilingHeight\"," +
            "\"suggested\":\"<value>\",\"reason\":\"<short reason>\"}],\"notes\":[\"<general note>\"]}";

        /// <summary>
        /// Requests finish suggestions for the supplied rooms using the configured provider. Runs
        /// entirely off the Revit API (network I/O only). Throws on errors with a friendly message.
        /// </summary>
        public async Task<AiFinishResult> SuggestAsync(
            IReadOnlyList<RoomViewModel> rooms,
            FinishOptionsProvider options,
            AppSettings settings,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(settings.ActiveApiKey))
                throw new InvalidOperationException("No API key configured. Open AI Settings and paste your key.");

            var userJson = BuildUserJson(rooms, options);

            return settings.IsGoogle
                ? await CallGeminiAsync(userJson, rooms, settings, cancellationToken).ConfigureAwait(false)
                : await CallAnthropicAsync(userJson, rooms, settings, cancellationToken).ConfigureAwait(false);
        }

        // ======================================================================================
        //  Shared payload (palette + rooms)
        // ======================================================================================

        private static string BuildUserJson(IReadOnlyList<RoomViewModel> rooms, FinishOptionsProvider options)
        {
            var payload = new
            {
                palette = new
                {
                    wall = options.WallFinishes.ToArray(),
                    floor = options.FloorFinishes.ToArray(),
                    ceiling = options.CeilingFinishes.ToArray(),
                    @base = options.BaseFinishes.ToArray()
                },
                rooms = rooms.Select(r => new
                {
                    id = r.ElementIdValue.ToString(),
                    number = r.Number,
                    name = r.Name,
                    department = r.Department,
                    level = r.Level,
                    wall = r.WallFinish,
                    floor = r.FloorFinish,
                    ceiling = r.CeilingFinish,
                    @base = r.BaseFinish,
                    ceiling_supported = r.CeilingHeightSupported
                }).ToArray()
            };

            return JsonSerializer.Serialize(payload);
        }

        // ======================================================================================
        //  Google Gemini
        // ======================================================================================

        private static async Task<AiFinishResult> CallGeminiAsync(
            string userJson, IReadOnlyList<RoomViewModel> rooms, AppSettings settings, CancellationToken ct)
        {
            var model = string.IsNullOrWhiteSpace(settings.GoogleModel) ? "gemini-2.0-flash" : settings.GoogleModel;
            var url = string.Format(GeminiEndpointFormat, model);

            var body = new
            {
                systemInstruction = new { parts = new[] { new { text = SystemPrompt } } },
                contents = new[]
                {
                    new { role = "user", parts = new[] { new { text = userJson } } }
                },
                generationConfig = new { responseMimeType = "application/json", temperature = 0.2 }
            };

            var json = JsonSerializer.Serialize(body);

            using (var request = new HttpRequestMessage(HttpMethod.Post, url))
            {
                request.Headers.Add("x-goog-api-key", settings.GoogleApiKey);
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");

                using (var response = await Http.SendAsync(request, ct).ConfigureAwait(false))
                {
                    var text = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    if (!response.IsSuccessStatusCode)
                        throw new InvalidOperationException(ExtractError(text, (int)response.StatusCode, "Gemini"));

                    return ParseGemini(text, rooms);
                }
            }
        }

        private static AiFinishResult ParseGemini(string responseText, IReadOnlyList<RoomViewModel> rooms)
        {
            using (var doc = JsonDocument.Parse(responseText))
            {
                var root = doc.RootElement;

                // Safety / prompt block with no candidates.
                if (!root.TryGetProperty("candidates", out var candidates) ||
                    candidates.ValueKind != JsonValueKind.Array || candidates.GetArrayLength() == 0)
                {
                    var note = "The model returned no suggestions.";
                    if (root.TryGetProperty("promptFeedback", out var pf) &&
                        pf.TryGetProperty("blockReason", out var br))
                    {
                        note = $"The request was blocked ({br.GetString()}).";
                    }
                    return new AiFinishResult { Notes = { note } };
                }

                var sb = new StringBuilder();
                var first = candidates[0];
                if (first.TryGetProperty("content", out var content) &&
                    content.TryGetProperty("parts", out var parts) && parts.ValueKind == JsonValueKind.Array)
                {
                    foreach (var part in parts.EnumerateArray())
                    {
                        if (part.TryGetProperty("text", out var t)) sb.Append(t.GetString());
                    }
                }

                var payloadJson = sb.ToString();
                if (string.IsNullOrWhiteSpace(payloadJson))
                    return new AiFinishResult { Notes = { "The model returned an empty response." } };

                return MapSuggestions(payloadJson, rooms);
            }
        }

        // ======================================================================================
        //  Anthropic Claude
        // ======================================================================================

        private static async Task<AiFinishResult> CallAnthropicAsync(
            string userJson, IReadOnlyList<RoomViewModel> rooms, AppSettings settings, CancellationToken ct)
        {
            var schema = new
            {
                type = "object",
                additionalProperties = false,
                properties = new
                {
                    changes = new
                    {
                        type = "array",
                        items = new
                        {
                            type = "object",
                            additionalProperties = false,
                            properties = new
                            {
                                id = new { type = "string" },
                                field = new
                                {
                                    type = "string",
                                    @enum = new[] { "WallFinish", "FloorFinish", "CeilingFinish", "BaseFinish", "CeilingHeight" }
                                },
                                suggested = new { type = "string" },
                                reason = new { type = "string" }
                            },
                            required = new[] { "id", "field", "suggested", "reason" }
                        }
                    },
                    notes = new { type = "array", items = new { type = "string" } }
                },
                required = new[] { "changes", "notes" }
            };

            var body = new
            {
                model = string.IsNullOrWhiteSpace(settings.AiModel) ? "claude-opus-4-8" : settings.AiModel,
                max_tokens = 16000,
                system = new object[]
                {
                    new { type = "text", text = SystemPrompt, cache_control = new { type = "ephemeral" } }
                },
                output_config = new { format = new { type = "json_schema", schema } },
                messages = new object[] { new { role = "user", content = userJson } }
            };

            var json = JsonSerializer.Serialize(body);

            using (var request = new HttpRequestMessage(HttpMethod.Post, AnthropicEndpoint))
            {
                request.Headers.Add("x-api-key", settings.AnthropicApiKey);
                request.Headers.Add("anthropic-version", AnthropicVersion);
                request.Content = new StringContent(json, Encoding.UTF8, "application/json");

                using (var response = await Http.SendAsync(request, ct).ConfigureAwait(false))
                {
                    var text = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    if (!response.IsSuccessStatusCode)
                        throw new InvalidOperationException(ExtractError(text, (int)response.StatusCode, "Anthropic"));

                    return ParseAnthropic(text, rooms);
                }
            }
        }

        private static AiFinishResult ParseAnthropic(string responseText, IReadOnlyList<RoomViewModel> rooms)
        {
            using (var doc = JsonDocument.Parse(responseText))
            {
                var root = doc.RootElement;

                if (root.TryGetProperty("stop_reason", out var stop) &&
                    string.Equals(stop.GetString(), "refusal", StringComparison.OrdinalIgnoreCase))
                {
                    return new AiFinishResult { Notes = { "The model declined to answer this request." } };
                }

                if (!root.TryGetProperty("content", out var content) || content.ValueKind != JsonValueKind.Array)
                    return new AiFinishResult();

                string payloadJson = null;
                foreach (var block in content.EnumerateArray())
                {
                    if (block.TryGetProperty("type", out var bt) && bt.GetString() == "text")
                    {
                        payloadJson = block.GetProperty("text").GetString();
                        break;
                    }
                }

                if (string.IsNullOrWhiteSpace(payloadJson)) return new AiFinishResult();
                return MapSuggestions(payloadJson, rooms);
            }
        }

        // ======================================================================================
        //  Shared: map the model's JSON {changes, notes} onto rooms
        // ======================================================================================

        private static AiFinishResult MapSuggestions(string payloadJson, IReadOnlyList<RoomViewModel> rooms)
        {
            var byId = rooms.ToDictionary(r => r.ElementIdValue.ToString(), r => r);
            var result = new AiFinishResult();

            // Models occasionally wrap JSON in code fences; strip them defensively.
            payloadJson = StripCodeFences(payloadJson);

            using (var payload = JsonDocument.Parse(payloadJson))
            {
                var p = payload.RootElement;

                if (p.TryGetProperty("notes", out var notes) && notes.ValueKind == JsonValueKind.Array)
                {
                    foreach (var n in notes.EnumerateArray())
                    {
                        var s = n.GetString();
                        if (!string.IsNullOrWhiteSpace(s)) result.Notes.Add(s);
                    }
                }

                if (p.TryGetProperty("changes", out var changes) && changes.ValueKind == JsonValueKind.Array)
                {
                    foreach (var c in changes.EnumerateArray())
                    {
                        if (!c.TryGetProperty("id", out var idEl)) continue;
                        var id = idEl.GetString();
                        if (id == null || !byId.TryGetValue(id, out var room)) continue;

                        if (!TryParseField(GetString(c, "field"), out var field)) continue;

                        var suggested = GetString(c, "suggested") ?? string.Empty;
                        var current = room.GetFieldValue(field) ?? string.Empty;

                        if (string.Equals(suggested, current, StringComparison.Ordinal)) continue;
                        if (field == RoomField.CeilingHeight && !room.CeilingHeightSupported) continue;

                        result.Changes.Add(new AiFinishChange
                        {
                            ElementIdValue = room.ElementIdValue,
                            RoomNumber = room.Number,
                            RoomName = room.Name,
                            Field = field,
                            CurrentValue = current,
                            SuggestedValue = suggested,
                            Reason = GetString(c, "reason") ?? string.Empty
                        });
                    }
                }
            }

            return result;
        }

        private static string StripCodeFences(string text)
        {
            text = text.Trim();
            if (text.StartsWith("```"))
            {
                int firstNewline = text.IndexOf('\n');
                if (firstNewline >= 0) text = text.Substring(firstNewline + 1);
                if (text.EndsWith("```")) text = text.Substring(0, text.Length - 3);
            }
            return text.Trim();
        }

        private static string GetString(JsonElement obj, string name)
            => obj.TryGetProperty(name, out var v) ? v.GetString() : null;

        private static bool TryParseField(string value, out RoomField field)
        {
            field = RoomField.WallFinish;
            if (string.IsNullOrEmpty(value)) return false;
            return Enum.TryParse(value, ignoreCase: true, result: out field)
                   && field != RoomField.Level && field != RoomField.Number && field != RoomField.Name;
        }

        private static string ExtractError(string responseText, int status, string provider)
        {
            try
            {
                using (var doc = JsonDocument.Parse(responseText))
                {
                    if (doc.RootElement.TryGetProperty("error", out var err) &&
                        err.TryGetProperty("message", out var msg))
                    {
                        return $"{provider} API error ({status}): {msg.GetString()}";
                    }
                }
            }
            catch
            {
                // fall through
            }

            if (status == 401 || status == 403)
                return $"{provider} API error ({status}): the API key looks invalid. Check it in AI Settings.";
            return $"{provider} API error ({status}). Please try again.";
        }
    }
}
