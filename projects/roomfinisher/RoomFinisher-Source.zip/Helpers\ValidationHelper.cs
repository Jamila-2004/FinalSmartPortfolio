using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using RoomFinisher.Models;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Helpers
{
    /// <summary>A single pre-commit validation finding.</summary>
    public sealed class ValidationIssue
    {
        public IssueSeverity Severity { get; set; }
        public string RoomNumber { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public long ElementIdValue { get; set; }
    }

    /// <summary>
    /// Pre-commit validation. Pure (no Revit API) so it runs instantly on the UI thread before we
    /// ever raise the commit ExternalEvent. The authoritative ceiling-height parse happens later on
    /// the Revit thread via UnitFormatUtils; here we only do a cheap sanity check.
    /// </summary>
    public static class ValidationHelper
    {
        public static List<ValidationIssue> Validate(IEnumerable<RoomViewModel> rooms)
        {
            var issues = new List<ValidationIssue>();

            foreach (var room in rooms)
            {
                // Missing room number is an error - rooms must be uniquely identifiable.
                if (string.IsNullOrWhiteSpace(room.Number))
                {
                    issues.Add(Make(IssueSeverity.Error, room, "Room number is missing."));
                }

                // Missing room name is a warning.
                if (string.IsNullOrWhiteSpace(room.Name))
                {
                    issues.Add(Make(IssueSeverity.Warning, room, "Room name is missing."));
                }

                // Empty finishes are warnings (a room with no finish assignment is suspicious but legal).
                AddIfEmpty(issues, room, room.WallFinish, "Wall Finish");
                AddIfEmpty(issues, room, room.FloorFinish, "Floor Finish");
                AddIfEmpty(issues, room, room.CeilingFinish, "Ceiling Finish");
                AddIfEmpty(issues, room, room.BaseFinish, "Base Finish");

                // Ceiling height: only validate when the model actually supports the parameter and a
                // value was entered. Negative / non-numeric values are errors.
                if (room.CeilingHeightSupported && !string.IsNullOrWhiteSpace(room.CeilingHeight))
                {
                    if (!LooksLikeValidLength(room.CeilingHeight))
                    {
                        issues.Add(Make(IssueSeverity.Error, room,
                            $"Ceiling height '{room.CeilingHeight}' is not a valid length."));
                    }
                }
            }

            return issues;
        }

        private static void AddIfEmpty(List<ValidationIssue> issues, RoomViewModel room, string value, string fieldName)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                issues.Add(Make(IssueSeverity.Warning, room, $"{fieldName} is empty."));
            }
        }

        /// <summary>
        /// Lenient length check: must contain at least one digit, and if it parses as a plain number
        /// it must be non-negative. Imperial strings like 9'-10" are accepted (digits present); the
        /// exact parse is validated by Revit at commit time.
        /// </summary>
        private static bool LooksLikeValidLength(string text)
        {
            if (!text.Any(char.IsDigit)) return false;

            if (double.TryParse(text, NumberStyles.Any, CultureInfo.CurrentCulture, out var v) ||
                double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out v))
            {
                return v >= 0;
            }

            // Could not parse as a plain number (e.g. feet-inches) but it has digits -> accept.
            return true;
        }

        private static ValidationIssue Make(IssueSeverity severity, RoomViewModel room, string message)
        {
            return new ValidationIssue
            {
                Severity = severity,
                RoomNumber = room.Number,
                Message = message,
                ElementIdValue = room.ElementIdValue
            };
        }
    }
}
