using System;
using System.Windows.Threading;
using Autodesk.Revit.UI;

namespace RoomFinisher.Revit
{
    /// <summary>
    /// A generic <see cref="IExternalEventHandler"/> that runs an arbitrary unit of Revit work on
    /// Revit's API thread and posts the result (or exception) back onto a WPF dispatcher.
    ///
    /// This is the bridge that makes a MODELESS window safe: WPF code can never call the Revit API
    /// from its own thread, so it queues a delegate here and the delegate is executed the next time
    /// Revit pumps its event queue.
    /// </summary>
    public sealed class RevitRequestRouter : IExternalEventHandler
    {
        private readonly ExternalEvent _externalEvent;

        private Func<UIApplication, object> _work;
        private Action<object> _onSuccess;
        private Action<Exception> _onError;
        private Dispatcher _dispatcher;

        // Only one request may be in flight at a time. The UI also disables buttons while busy.
        private volatile bool _busy;

        public RevitRequestRouter()
        {
            // Must be created from a valid Revit context (we do so inside the external command).
            _externalEvent = ExternalEvent.Create(this);
        }

        public bool IsBusy => _busy;

        /// <summary>
        /// Queues a unit of work. Returns false if Revit is already processing another request.
        /// </summary>
        public bool Enqueue(
            Func<UIApplication, object> work,
            Action<object> onSuccess,
            Action<Exception> onError,
            Dispatcher dispatcher)
        {
            if (_busy) return false;

            _busy = true;
            _work = work;
            _onSuccess = onSuccess;
            _onError = onError;
            _dispatcher = dispatcher;

            _externalEvent.Raise();
            return true;
        }

        /// <summary>Called by Revit on its own thread when the event is serviced.</summary>
        public void Execute(UIApplication app)
        {
            object result = null;
            Exception error = null;

            try
            {
                result = _work?.Invoke(app);
            }
            catch (Exception ex)
            {
                error = ex;
            }

            // Capture locals before clearing the busy flag so a new request can be queued.
            var dispatcher = _dispatcher;
            var onSuccess = _onSuccess;
            var onError = _onError;

            _busy = false;

            if (dispatcher == null) return;

            dispatcher.Invoke(() =>
            {
                if (error != null) onError?.Invoke(error);
                else onSuccess?.Invoke(result);
            });
        }

        public string GetName() => "Room Finisher Request Router";
    }
}
