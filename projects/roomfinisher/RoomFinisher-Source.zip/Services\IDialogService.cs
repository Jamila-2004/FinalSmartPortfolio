using System.Collections.Generic;
using RoomFinisher.Helpers;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Services
{
    /// <summary>
    /// Abstraction over the windows/dialogs the ViewModel needs to show. Keeps MainViewModel free of
    /// direct references to WPF Window types (the concrete implementation lives in the Views layer),
    /// which keeps the ViewModel testable and the MVVM boundary clean.
    /// </summary>
    public interface IDialogService
    {
        void ShowInfo(string title, string message);
        void ShowError(string title, string message);
        bool Confirm(string title, string message);

        /// <summary>Shows validation findings. Returns true if the user chooses to proceed anyway.</summary>
        bool ShowValidation(IList<ValidationIssue> issues);

        /// <summary>Shows the Review Changes window. Returns true when the user confirms the commit.</summary>
        bool ShowReview(ReviewChangesViewModel viewModel);

        /// <summary>Shows the Bulk Edit dialog. Returns true when the user applied a value.</summary>
        bool ShowBulkEdit(BulkEditViewModel viewModel);

        /// <summary>Shows the template apply dialog (scope + preview). Returns true when applied.</summary>
        bool ShowApplyTemplate(ApplyTemplateViewModel viewModel);

        void ShowAnalytics(AnalyticsViewModel viewModel);
        void ShowQualityReport(QualityReportViewModel viewModel);

        /// <summary>Shows the AI suggestions approval window. Returns true when the user applies.</summary>
        bool ShowAiSuggestions(AiSuggestionsViewModel viewModel);

        /// <summary>Shows the AI settings (API key / model) dialog. Returns true when saved.</summary>
        bool ShowAiSettings(AiSettingsViewModel viewModel);

        /// <summary>Open-file dialog. Returns the chosen path or null if cancelled.</summary>
        string OpenFile(string filter, string initialDirectory);

        /// <summary>Save-file dialog. Returns the chosen path or null if cancelled.</summary>
        string SaveFile(string filter, string defaultFileName, string initialDirectory);
    }
}
