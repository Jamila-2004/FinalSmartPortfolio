using System.Collections.Generic;
using System.Linq;
using RoomFinisher.Models;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Services
{
    /// <summary>
    /// Aggregates finish usage across the loaded rooms using LINQ grouping. Recomputed whenever the
    /// room data changes so the Analytics window stays in sync in real time.
    /// </summary>
    public sealed class AnalyticsService
    {
        public AnalyticsData Build(IEnumerable<RoomViewModel> rooms)
        {
            var list = rooms?.ToList() ?? new List<RoomViewModel>();
            var data = new AnalyticsData { TotalRooms = list.Count };

            data.WallFinishes = Distribution(list, r => r.WallFinish);
            data.FloorFinishes = Distribution(list, r => r.FloorFinish);
            data.CeilingFinishes = Distribution(list, r => r.CeilingFinish);
            data.BaseFinishes = Distribution(list, r => r.BaseFinish);

            data.MostCommonWall = MostCommon(data.WallFinishes);
            data.MostCommonFloor = MostCommon(data.FloorFinishes);
            data.MostCommonCeiling = MostCommon(data.CeilingFinishes);
            data.MostCommonBase = MostCommon(data.BaseFinishes);

            return data;
        }

        /// <summary>Groups rooms by one finish field into counts + percentages, ordered by count desc.</summary>
        private static List<FinishCount> Distribution(
            IReadOnlyCollection<RoomViewModel> rooms,
            System.Func<RoomViewModel, string> selector)
        {
            int total = rooms.Count;

            return rooms
                .Select(r =>
                {
                    var v = selector(r);
                    return string.IsNullOrWhiteSpace(v) ? "(none)" : v.Trim();
                })
                .GroupBy(v => v)
                .Select(g => new FinishCount
                {
                    Name = g.Key,
                    Count = g.Count(),
                    Percentage = total == 0 ? 0 : (g.Count() * 100.0 / total)
                })
                .OrderByDescending(f => f.Count)
                .ThenBy(f => f.Name)
                .ToList();
        }

        private static string MostCommon(List<FinishCount> dist)
        {
            // Skip the "(none)" bucket when deciding the most common real finish.
            var top = dist.FirstOrDefault(d => d.Name != "(none)") ?? dist.FirstOrDefault();
            return top == null ? "-" : $"{top.Name}  ·  {top.Count} ({top.Percentage:0}%)";
        }
    }
}
