using System;
using System.Reflection;
using Autodesk.Revit.UI;

namespace RoomFinisher.App
{
    /// <summary>
    /// Add-in entry point. Builds the "Room Finisher" ribbon tab and the "Open Room Finisher"
    /// button when Revit starts. Registered via RoomFinisher.addin (&lt;AddIn Type="Application"&gt;).
    /// </summary>
    public sealed class RoomFinisherApplication : IExternalApplication
    {
        private const string TabName = "Room Finisher";
        private const string PanelName = "Finishes";

        public Result OnStartup(UIControlledApplication application)
        {
            try
            {
                // Create the ribbon tab (guarded - CreateRibbonTab throws if it already exists).
                try { application.CreateRibbonTab(TabName); }
                catch { /* tab already exists (e.g. add-in reloaded) - reuse it */ }

                var panel = application.CreateRibbonPanel(TabName, PanelName);

                var assemblyPath = Assembly.GetExecutingAssembly().Location;

                var buttonData = new PushButtonData(
                    name: "OpenRoomFinisher",
                    text: "Open Room\nFinisher",
                    assemblyName: assemblyPath,
                    className: "RoomFinisher.Commands.OpenRoomFinisherCommand")
                {
                    ToolTip = "Edit room finish schedules in a spreadsheet-like editor and push all " +
                              "changes back to Revit in a single transaction.",
                    LongDescription = "Room Finisher loads every room into an editable grid with bulk " +
                                      "edit, templates, validation, analytics, quality checks and Excel export."
                };

                panel.AddItem(buttonData);

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                // Never let a startup error crash Revit; surface a message instead.
                TaskDialog.Show("Room Finisher", "Failed to initialize the add-in:\n\n" + ex.Message);
                return Result.Failed;
            }
        }

        public Result OnShutdown(UIControlledApplication application)
        {
            return Result.Succeeded;
        }
    }
}
