using System.Windows;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Views
{
    /// <summary>AI suggestions approval dialog. "Apply Selected" returns DialogResult true.</summary>
    public partial class AiSuggestionsWindow : Window
    {
        public AiSuggestionsWindow(AiSuggestionsViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
            viewModel.RequestClose += result =>
            {
                DialogResult = result;
                Close();
            };
        }
    }
}
