using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using RoomFinisher.Models;

namespace RoomFinisher.Resources
{
    /// <summary>
    /// bool -> Brush. True returns the shared "modified" highlight (yellow); false returns
    /// Transparent. Used to tint modified rows/cells in the DataGrid.
    /// </summary>
    public sealed class BoolToHighlightBrushConverter : IValueConverter
    {
        private static readonly Brush Highlight = new SolidColorBrush(Color.FromRgb(255, 247, 194)); // soft yellow
        private static readonly Brush None = Brushes.Transparent;

        static BoolToHighlightBrushConverter()
        {
            Highlight.Freeze();
        }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (value is bool b && b) ? Highlight : None;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotSupportedException();
    }

    /// <summary>IssueSeverity -> Brush. Error = red, Warning = amber.</summary>
    public sealed class SeverityToBrushConverter : IValueConverter
    {
        private static readonly Brush Error = new SolidColorBrush(Color.FromRgb(0xD3, 0x2F, 0x2F));
        private static readonly Brush Warning = new SolidColorBrush(Color.FromRgb(0xF5, 0x9E, 0x0B));

        static SeverityToBrushConverter()
        {
            Error.Freeze();
            Warning.Freeze();
        }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value is IssueSeverity s && s == IssueSeverity.Error ? Error : Warning;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotSupportedException();
    }

    /// <summary>
    /// bool -> Visibility. Pass ConverterParameter="Invert" to flip the result. Useful for
    /// "modified indicator" glyphs and empty-state messages.
    /// </summary>
    public sealed class BoolToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool flag = value is bool b && b;
            if (parameter is string s && string.Equals(s, "Invert", StringComparison.OrdinalIgnoreCase))
                flag = !flag;
            return flag ? Visibility.Visible : Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value is Visibility v && v == Visibility.Visible;
        }
    }
}
