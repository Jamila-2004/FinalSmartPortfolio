using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using RoomFinisher.Helpers;
using RoomFinisher.Models;
using RoomFinisher.Services;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// Backs the Apply Template dialog. Lets the user choose a scope (All / Selected / By Department)
    /// and which finishes to include, previews the resulting changes, and on confirm applies them to
    /// the target rooms (dirty-tracked, so they still go through the normal Review + commit flow).
    ///
    /// Note: Revit rooms have no family "type", so the spec's "apply by room type" is mapped to
    /// "by Department", which is the closest native grouping.
    /// </summary>
    public sealed class ApplyTemplateViewModel : ViewModelBase
    {
        private readonly FinishTemplate _template;
        private readonly ObservableCollection<RoomViewModel> _allRooms;
        private readonly IList<RoomViewModel> _selectedRooms;

        private bool _applyToAll = true;
        private bool _applyToSelected;
        private bool _applyByDepartment;
        private string _selectedDepartment;

        private bool _includeWall;
        private bool _includeFloor;
        private bool _includeCeiling;
        private bool _includeBase;
        private bool _includeCeilingHeight;

        public ApplyTemplateViewModel(
            FinishTemplate template,
            ObservableCollection<RoomViewModel> allRooms,
            IList<RoomViewModel> selectedRooms,
            IEnumerable<string> departments,
            ChangeTrackingService tracking)
        {
            _template = template ?? new FinishTemplate();
            _allRooms = allRooms;
            _selectedRooms = selectedRooms ?? new List<RoomViewModel>();

            Departments = new ObservableCollection<string>(departments ?? Enumerable.Empty<string>());
            _selectedDepartment = Departments.FirstOrDefault();

            // Default-include any finish the template actually specifies.
            _includeWall = !string.IsNullOrWhiteSpace(_template.WallFinish);
            _includeFloor = !string.IsNullOrWhiteSpace(_template.FloorFinish);
            _includeCeiling = !string.IsNullOrWhiteSpace(_template.CeilingFinish);
            _includeBase = !string.IsNullOrWhiteSpace(_template.BaseFinish);
            _includeCeilingHeight = !string.IsNullOrWhiteSpace(_template.CeilingHeight);

            Preview = new ObservableCollection<ChangeRecord>();

            ApplyCommand = new RelayCommand(Apply, () => Preview.Count > 0);
            CancelCommand = new RelayCommand(() => RequestClose?.Invoke(false));

            RefreshPreview();
        }

        public event Action<bool> RequestClose;

        // ---- Template summary (read-only display) --------------------------------------------
        public string TemplateName => _template.Name;
        public string WallFinish => _template.WallFinish;
        public string FloorFinish => _template.FloorFinish;
        public string CeilingFinish => _template.CeilingFinish;
        public string BaseFinish => _template.BaseFinish;
        public string CeilingHeight => _template.CeilingHeight;

        public bool HasSelection => _selectedRooms.Count > 0;
        public bool HasDepartments => Departments.Count > 0;
        public ObservableCollection<string> Departments { get; }

        // ---- Scope (mutually exclusive radios) -----------------------------------------------
        public bool ApplyToAll
        {
            get => _applyToAll;
            set { if (SetProperty(ref _applyToAll, value) && value) RefreshPreview(); }
        }

        public bool ApplyToSelected
        {
            get => _applyToSelected;
            set { if (SetProperty(ref _applyToSelected, value) && value) RefreshPreview(); }
        }

        public bool ApplyByDepartment
        {
            get => _applyByDepartment;
            set { if (SetProperty(ref _applyByDepartment, value) && value) RefreshPreview(); }
        }

        public string SelectedDepartment
        {
            get => _selectedDepartment;
            set { if (SetProperty(ref _selectedDepartment, value)) RefreshPreview(); }
        }

        // ---- Include toggles -----------------------------------------------------------------
        public bool IncludeWall { get => _includeWall; set { if (SetProperty(ref _includeWall, value)) RefreshPreview(); } }
        public bool IncludeFloor { get => _includeFloor; set { if (SetProperty(ref _includeFloor, value)) RefreshPreview(); } }
        public bool IncludeCeiling { get => _includeCeiling; set { if (SetProperty(ref _includeCeiling, value)) RefreshPreview(); } }
        public bool IncludeBase { get => _includeBase; set { if (SetProperty(ref _includeBase, value)) RefreshPreview(); } }
        public bool IncludeCeilingHeight { get => _includeCeilingHeight; set { if (SetProperty(ref _includeCeilingHeight, value)) RefreshPreview(); } }

        public ObservableCollection<ChangeRecord> Preview { get; }

        public int AffectedRooms =>
            Preview.Select(p => p.RoomNumber).Distinct(StringComparer.OrdinalIgnoreCase).Count();

        public string FooterSummary => $"Rooms Affected: {AffectedRooms}    Parameter Changes: {Preview.Count}";

        public ICommand ApplyCommand { get; }
        public ICommand CancelCommand { get; }

        // ======================================================================================

        private IEnumerable<RoomViewModel> TargetRooms()
        {
            if (ApplyToSelected) return _selectedRooms;
            if (ApplyByDepartment)
                return _allRooms.Where(r => string.Equals(r.Department, SelectedDepartment, StringComparison.OrdinalIgnoreCase));
            return _allRooms;
        }

        private IEnumerable<RoomField> IncludedFields()
        {
            if (IncludeWall && !string.IsNullOrWhiteSpace(_template.WallFinish)) yield return RoomField.WallFinish;
            if (IncludeFloor && !string.IsNullOrWhiteSpace(_template.FloorFinish)) yield return RoomField.FloorFinish;
            if (IncludeCeiling && !string.IsNullOrWhiteSpace(_template.CeilingFinish)) yield return RoomField.CeilingFinish;
            if (IncludeBase && !string.IsNullOrWhiteSpace(_template.BaseFinish)) yield return RoomField.BaseFinish;
            if (IncludeCeilingHeight && !string.IsNullOrWhiteSpace(_template.CeilingHeight)) yield return RoomField.CeilingHeight;
        }

        private string TemplateValue(RoomField field)
        {
            switch (field)
            {
                case RoomField.WallFinish: return _template.WallFinish;
                case RoomField.FloorFinish: return _template.FloorFinish;
                case RoomField.CeilingFinish: return _template.CeilingFinish;
                case RoomField.BaseFinish: return _template.BaseFinish;
                case RoomField.CeilingHeight: return _template.CeilingHeight;
                default: return string.Empty;
            }
        }

        private void RefreshPreview()
        {
            Preview.Clear();

            var fields = IncludedFields().ToList();
            foreach (var room in TargetRooms())
            {
                foreach (var field in fields)
                {
                    // Skip ceiling height on rooms that don't support the parameter.
                    if (field == RoomField.CeilingHeight && !room.CeilingHeightSupported) continue;

                    var newValue = TemplateValue(field);
                    var current = room.GetFieldValue(field);
                    if (!string.Equals(current ?? string.Empty, newValue ?? string.Empty, StringComparison.Ordinal))
                    {
                        Preview.Add(new ChangeRecord
                        {
                            RoomNumber = room.Number,
                            RoomName = room.Name,
                            Parameter = field.ToDisplayName(),
                            OriginalValue = current,
                            NewValue = newValue
                        });
                    }
                }
            }

            RaisePropertyChanged(nameof(AffectedRooms));
            RaisePropertyChanged(nameof(FooterSummary));
        }

        private void Apply()
        {
            var fields = IncludedFields().ToList();
            foreach (var room in TargetRooms().ToList())
            {
                foreach (var field in fields)
                {
                    if (field == RoomField.CeilingHeight && !room.CeilingHeightSupported) continue;
                    room.SetFieldValue(field, TemplateValue(field));
                }
            }
            RequestClose?.Invoke(true);
        }
    }
}
