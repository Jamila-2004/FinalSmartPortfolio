using System.IO;
using System.Text.Json;
using RoomFinisher.Models;

namespace RoomFinisher.Services
{
    /// <summary>
    /// Saves/loads <see cref="FinishTemplate"/> objects as JSON using System.Text.Json
    /// (deliberately NOT Newtonsoft, which Revit already loads and would conflict with).
    /// </summary>
    public sealed class TemplateService
    {
        private static readonly JsonSerializerOptions Options = new JsonSerializerOptions
        {
            WriteIndented = true
        };

        /// <summary>Serializes a template to the given path. Throws on IO errors (caller reports them).</summary>
        public void Save(FinishTemplate template, string path)
        {
            var json = JsonSerializer.Serialize(template, Options);
            File.WriteAllText(path, json);
        }

        /// <summary>Reads a template from disk. Throws on IO/format errors (caller reports them).</summary>
        public FinishTemplate Load(string path)
        {
            var json = File.ReadAllText(path);
            var template = JsonSerializer.Deserialize<FinishTemplate>(json);
            return template ?? new FinishTemplate();
        }
    }
}
