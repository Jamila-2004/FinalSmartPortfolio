using System;
using System.Collections.Generic;
using System.Windows.Threading;
using Autodesk.Revit.DB;
using RoomFinisher.Models;
using RoomFinisher.RevitServices;
using RoomFinisher.Services;

namespace RoomFinisher.Revit
{
    /// <summary>
    /// Concrete <see cref="IRevitWorker"/>. Holds the target document and the shared
    /// <see cref="RevitRequestRouter"/>, wrapping each operation as a delegate that runs on the
    /// Revit thread. Results are returned to the UI thread via the WPF dispatcher.
    /// </summary>
    public sealed class RevitWorker : IRevitWorker
    {
        private readonly Document _doc;
        private readonly RevitRequestRouter _router;
        private readonly AppSettings _settings;
        private readonly RoomCollectorService _collector = new RoomCollectorService();
        private readonly RevitTransactionService _transaction = new RevitTransactionService();

        public RevitWorker(Document doc, RevitRequestRouter router, AppSettings settings)
        {
            _doc = doc ?? throw new ArgumentNullException(nameof(doc));
            _router = router ?? throw new ArgumentNullException(nameof(router));
            _settings = settings ?? new AppSettings();
        }

        public bool IsBusy => _router.IsBusy;

        public void CollectRooms(Action<IList<RoomData>> onDone, Action<string> onError)
        {
            bool queued = _router.Enqueue(
                work: app => (object)_collector.Collect(_doc, _settings),
                onSuccess: res => onDone?.Invoke((IList<RoomData>)res),
                onError: ex => onError?.Invoke(ex.Message),
                dispatcher: GetDispatcher());

            if (!queued) onError?.Invoke("Revit is busy processing another request. Please try again in a moment.");
        }

        public void ApplyChanges(IList<RoomChangeSet> changes, Action<CommitResult> onDone, Action<string> onError)
        {
            bool queued = _router.Enqueue(
                work: app => (object)_transaction.Apply(_doc, changes, _settings),
                onSuccess: res => onDone?.Invoke((CommitResult)res),
                onError: ex => onError?.Invoke(ex.Message),
                dispatcher: GetDispatcher());

            if (!queued) onError?.Invoke("Revit is busy processing another request. Please try again in a moment.");
        }

        public void ShowInRevit(IList<long> elementIdValues, Action onDone, Action<string> onError)
        {
            bool queued = _router.Enqueue(
                work: app =>
                {
                    var uiDoc = app.ActiveUIDocument;
                    if (uiDoc == null) return null;

                    // Keep only ids that still exist in the model.
                    var ids = new List<ElementId>();
                    foreach (var value in elementIdValues)
                    {
                        var id = new ElementId(value);
                        if (uiDoc.Document.GetElement(id) != null) ids.Add(id);
                    }

                    if (ids.Count > 0)
                    {
                        uiDoc.Selection.SetElementIds(ids);
                        uiDoc.ShowElements(ids); // zooms/fits the active (or a suitable) view to the rooms
                    }
                    return null;
                },
                onSuccess: _ => onDone?.Invoke(),
                onError: ex => onError?.Invoke(ex.Message),
                dispatcher: GetDispatcher());

            if (!queued) onError?.Invoke("Revit is busy processing another request. Please try again in a moment.");
        }

        /// <summary>The UI dispatcher to marshal callbacks back onto (the window's thread).</summary>
        private static Dispatcher GetDispatcher()
        {
            return System.Windows.Application.Current?.Dispatcher ?? Dispatcher.CurrentDispatcher;
        }
    }
}
