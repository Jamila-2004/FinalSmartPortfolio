# =====================================================================================
#  Room Finisher - one-click deploy script
#
#  Copies the built add-in into your PER-USER Revit add-ins folder (no admin needed):
#      %APPDATA%\Autodesk\Revit\Addins\<version>\
#
#  Usage (from a PowerShell window in this folder):
#      .\deploy.ps1            # deploys for Revit 2025 (default)
#      .\deploy.ps1 -Version 2026
#
#  After it runs, just (re)start Revit and open a project - the "Room Finisher" tab
#  will be on the ribbon.
# =====================================================================================
param(
    [string]$Version = "2025"
)

$ErrorActionPreference = "Stop"

# Folder this script lives in (the solution root).
$projectRoot = $PSScriptRoot

$binFolder  = Join-Path $projectRoot "RoomFinisher\bin\x64\Release"
$addinFile  = Join-Path $projectRoot "RoomFinisher\RoomFinisher.addin"

# Per-user Revit add-ins folder for the chosen version.
$addinsRoot = Join-Path $env:APPDATA "Autodesk\Revit\Addins\$Version"
$dllFolder  = Join-Path $addinsRoot "RoomFinisher"

Write-Host "Room Finisher deploy -> Revit $Version" -ForegroundColor Cyan

# 1. Make sure the project was built.
if (-not (Test-Path (Join-Path $binFolder "RoomFinisher.dll"))) {
    Write-Host "ERROR: RoomFinisher.dll was not found in:" -ForegroundColor Red
    Write-Host "  $binFolder"
    Write-Host "Build it first:  dotnet build `"RoomFinisher\RoomFinisher.csproj`" -c Release -p:Platform=x64"
    exit 1
}

# 2. Create the destination folder and clear any stale DLLs from a previous deploy
#    (so removed dependencies like OxyPlot don't linger).
New-Item -ItemType Directory -Force -Path $dllFolder | Out-Null
Get-ChildItem -Path $dllFolder -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue

# 3. Copy all DLLs (and supporting files) into the RoomFinisher subfolder.
Copy-Item -Path (Join-Path $binFolder "*") -Destination $dllFolder -Recurse -Force

# 4. Copy the .addin manifest into the Addins\<version> folder.
Copy-Item -Path $addinFile -Destination $addinsRoot -Force

Write-Host "Done." -ForegroundColor Green
Write-Host "Manifest : $addinsRoot\RoomFinisher.addin"
Write-Host "DLLs     : $dllFolder"
Write-Host "Now restart Revit $Version and open a project."
