using System.Collections.Generic;
using RoomFinisher.Models;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Services
{
    /// <summary>One reversible edit: a field on a room changed from OldValue to NewValue.</summary>
    public sealed class EditAction
    {
        public RoomViewModel Room { get; set; }
        public RoomField Field { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
    }

    /// <summary>
    /// Local, pre-commit undo stack. This is NOT a Revit transaction - it only reverts edits made in
    /// the grid before they are pushed to the model. After a successful commit the stack is cleared
    /// (from then on, Revit's own undo owns the change).
    /// </summary>
    public sealed class UndoService
    {
        private readonly Stack<EditAction> _stack = new Stack<EditAction>();

        public bool CanUndo => _stack.Count > 0;
        public int Count => _stack.Count;

        /// <summary>Records an edit. Called by <see cref="RoomViewModel"/> whenever a user/bulk edit occurs.</summary>
        public void Record(RoomViewModel room, RoomField field, string oldValue, string newValue)
        {
            _stack.Push(new EditAction
            {
                Room = room,
                Field = field,
                OldValue = oldValue,
                NewValue = newValue
            });
        }

        /// <summary>
        /// Reverts the most recent edit and returns it (or null if empty). The restore is applied
        /// without recording a new undo entry.
        /// </summary>
        public EditAction Undo()
        {
            if (_stack.Count == 0) return null;
            var action = _stack.Pop();
            action.Room?.RestoreFieldValue(action.Field, action.OldValue);
            return action;
        }

        /// <summary>Reverts the last <paramref name="count"/> edits.</summary>
        public void Undo(int count)
        {
            for (int i = 0; i < count && CanUndo; i++)
            {
                Undo();
            }
        }

        /// <summary>Clears the stack (after a successful commit or a refresh).</summary>
        public void Clear() => _stack.Clear();
    }
}
