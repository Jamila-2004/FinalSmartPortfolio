using System.Windows;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Views
{
    /// <summary>Review Changes dialog. Confirm = DialogResult true triggers the Revit transaction.</summary>
    public partial class ReviewChangesWindow : Window
    {
        public ReviewChangesWindow(ReviewChangesViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
            viewModel.RequestClose += result =>
            {
                DialogResult = result;
                Close();
            };
        }
    }
}
