using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Views
{
    /// <summary>
    /// Code-behind for the main window. Contains ONLY view plumbing (forwarding the multi-select
    /// grid's selection to the ViewModel and selecting a row on right-click so the context menu acts
    /// on it). All behaviour lives in <see cref="MainViewModel"/>.
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _viewModel;

        public MainWindow(MainViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            DataContext = viewModel;
        }

        /// <summary>
        /// WPF's DataGrid.SelectedItems is not bindable, so we forward the current selection to the
        /// ViewModel here. This is pure plumbing, not business logic.
        /// </summary>
        private void RoomsGrid_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_viewModel != null)
            {
                _viewModel.SelectedRooms = RoomsGrid.SelectedItems;
            }
        }

        /// <summary>
        /// Selects the row under the cursor on right-click (if it isn't already selected) so the
        /// "Show in Revit" context-menu item targets the expected room.
        /// </summary>
        private void Row_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is DataGridRow row && !row.IsSelected)
            {
                RoomsGrid.SelectedItem = row.Item;
            }
        }
    }
}
