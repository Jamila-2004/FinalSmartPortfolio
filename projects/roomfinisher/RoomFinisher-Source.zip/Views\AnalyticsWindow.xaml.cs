using System.Windows;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Views
{
    /// <summary>
    /// Analytics window. Shown modeless so the user can keep editing rooms and watch the charts
    /// update in real time (MainViewModel re-runs the analytics ViewModel after each edit).
    /// </summary>
    public partial class AnalyticsWindow : Window
    {
        public AnalyticsWindow(AnalyticsViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }

        private void Close_OnClick(object sender, RoutedEventArgs e) => Close();
    }
}
