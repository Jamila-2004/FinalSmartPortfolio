using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace RoomFinisher.Models
{
    /// <summary>
    /// Default dropdown values for each finish type, plus a session-scoped provider that backs the
    /// editable combo-boxes. Users may pick a default OR type a custom value; custom values are
    /// added back into the relevant list (via <see cref="FinishOptionsProvider.AddIfMissing"/>) so
    /// they become reusable for the rest of the session.
    /// </summary>
    public static class FinishOptions
    {
        public static readonly string[] WallFinishes =
        {
            "Paint", "Gypsum Board", "Ceramic Tile", "Marble", "Stone Cladding"
        };

        public static readonly string[] FloorFinishes =
        {
            "Ceramic Tile", "Porcelain", "Marble", "Vinyl", "Concrete"
        };

        public static readonly string[] CeilingFinishes =
        {
            "Gypsum Board", "Acoustic Tile", "Exposed Ceiling", "Metal Ceiling"
        };

        public static readonly string[] BaseFinishes =
        {
            "Painted Skirting", "Marble Skirting", "Tile Skirting", "Wooden Skirting"
        };
    }

    /// <summary>
    /// Holds the live, bindable option lists for the four finish columns. A single instance is
    /// shared by every <see cref="ViewModels.RoomViewModel"/> and the bulk-edit dialog so a newly
    /// typed value appears everywhere.
    /// </summary>
    public sealed class FinishOptionsProvider
    {
        public ObservableCollection<string> WallFinishes { get; }
        public ObservableCollection<string> FloorFinishes { get; }
        public ObservableCollection<string> CeilingFinishes { get; }
        public ObservableCollection<string> BaseFinishes { get; }

        public FinishOptionsProvider()
        {
            WallFinishes = new ObservableCollection<string>(FinishOptions.WallFinishes);
            FloorFinishes = new ObservableCollection<string>(FinishOptions.FloorFinishes);
            CeilingFinishes = new ObservableCollection<string>(FinishOptions.CeilingFinishes);
            BaseFinishes = new ObservableCollection<string>(FinishOptions.BaseFinishes);
        }

        /// <summary>Returns the option list for a given finish field (null for non-finish fields).</summary>
        public ObservableCollection<string> GetList(RoomField field)
        {
            switch (field)
            {
                case RoomField.WallFinish: return WallFinishes;
                case RoomField.FloorFinish: return FloorFinishes;
                case RoomField.CeilingFinish: return CeilingFinishes;
                case RoomField.BaseFinish: return BaseFinishes;
                default: return null;
            }
        }

        /// <summary>Adds a custom value to the appropriate list if it is non-empty and not already present.</summary>
        public void AddIfMissing(RoomField field, string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return;
            var list = GetList(field);
            if (list == null) return;
            if (!list.Any(v => string.Equals(v, value, System.StringComparison.OrdinalIgnoreCase)))
            {
                list.Add(value);
            }
        }

        /// <summary>Seeds the option lists with any custom finishes already present in the model.</summary>
        public void SeedFromRooms(IEnumerable<RoomData> rooms)
        {
            foreach (var r in rooms)
            {
                AddIfMissing(RoomField.WallFinish, r.WallFinish);
                AddIfMissing(RoomField.FloorFinish, r.FloorFinish);
                AddIfMissing(RoomField.CeilingFinish, r.CeilingFinish);
                AddIfMissing(RoomField.BaseFinish, r.BaseFinish);
            }
        }
    }
}
