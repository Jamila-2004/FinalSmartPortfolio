using System.Windows;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Views
{
    /// <summary>Apply Template dialog. Code-behind only forwards the close request.</summary>
    public partial class ApplyTemplateWindow : Window
    {
        public ApplyTemplateWindow(ApplyTemplateViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
            viewModel.RequestClose += result =>
            {
                DialogResult = result;
                Close();
            };
        }
    }
}
