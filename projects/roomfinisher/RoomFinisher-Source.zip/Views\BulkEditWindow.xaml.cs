using System.Windows;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Views
{
    /// <summary>Bulk Edit dialog. Code-behind only wires the VM's close request to DialogResult.</summary>
    public partial class BulkEditWindow : Window
    {
        public BulkEditWindow(BulkEditViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
            viewModel.RequestClose += result =>
            {
                DialogResult = result;
                Close();
            };
        }
    }
}
