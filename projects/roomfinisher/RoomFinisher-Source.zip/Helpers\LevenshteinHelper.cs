using System;

namespace RoomFinisher.Helpers
{
    /// <summary>
    /// Computes Levenshtein edit distance, used by the quality engine to flag near-duplicate finish
    /// names such as "Marble" vs "Marbel". Case-insensitive comparison is the caller's choice.
    /// </summary>
    public static class LevenshteinHelper
    {
        /// <summary>Edit distance between two strings (number of single-character edits).</summary>
        public static int Distance(string a, string b)
        {
            a ??= string.Empty;
            b ??= string.Empty;

            if (a.Length == 0) return b.Length;
            if (b.Length == 0) return a.Length;

            // Two-row dynamic programming to keep memory at O(min length).
            var previous = new int[b.Length + 1];
            var current = new int[b.Length + 1];

            for (int j = 0; j <= b.Length; j++) previous[j] = j;

            for (int i = 1; i <= a.Length; i++)
            {
                current[0] = i;
                for (int j = 1; j <= b.Length; j++)
                {
                    int cost = a[i - 1] == b[j - 1] ? 0 : 1;
                    current[j] = Math.Min(
                        Math.Min(current[j - 1] + 1,   // insertion
                                 previous[j] + 1),      // deletion
                        previous[j - 1] + cost);        // substitution
                }

                // swap rows
                var tmp = previous;
                previous = current;
                current = tmp;
            }

            return previous[b.Length];
        }

        /// <summary>True when two non-identical strings are within <paramref name="maxDistance"/> edits (case-insensitive).</summary>
        public static bool AreSimilar(string a, string b, int maxDistance = 2)
        {
            if (string.IsNullOrWhiteSpace(a) || string.IsNullOrWhiteSpace(b)) return false;
            if (string.Equals(a, b, StringComparison.OrdinalIgnoreCase)) return false; // identical, not "similar"
            int d = Distance(a.ToLowerInvariant(), b.ToLowerInvariant());
            return d > 0 && d <= maxDistance;
        }
    }
}
