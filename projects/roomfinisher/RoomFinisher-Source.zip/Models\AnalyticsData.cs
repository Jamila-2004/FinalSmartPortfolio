using System.Collections.Generic;

namespace RoomFinisher.Models
{
    /// <summary>One bucket in a finish distribution: the finish name, its count and percentage.</summary>
    public sealed class FinishCount
    {
        public string Name { get; set; } = string.Empty;
        public int Count { get; set; }
        public double Percentage { get; set; }

        /// <summary>Convenience label for charts/lists, e.g. "Paint (42, 70%)".</summary>
        public string Label => $"{Name} ({Count}, {Percentage:0.#}%)";
    }

    /// <summary>
    /// Aggregated finish statistics across the currently loaded rooms. Produced by
    /// <see cref="Services.AnalyticsService"/> using LINQ grouping and bound by the
    /// Analytics window.
    /// </summary>
    public sealed class AnalyticsData
    {
        public int TotalRooms { get; set; }

        public List<FinishCount> WallFinishes { get; set; } = new List<FinishCount>();
        public List<FinishCount> FloorFinishes { get; set; } = new List<FinishCount>();
        public List<FinishCount> CeilingFinishes { get; set; } = new List<FinishCount>();
        public List<FinishCount> BaseFinishes { get; set; } = new List<FinishCount>();

        public string MostCommonWall { get; set; } = "-";
        public string MostCommonFloor { get; set; } = "-";
        public string MostCommonCeiling { get; set; } = "-";
        public string MostCommonBase { get; set; } = "-";
    }
}
