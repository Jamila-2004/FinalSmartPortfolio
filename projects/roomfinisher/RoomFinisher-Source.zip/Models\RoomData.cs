namespace RoomFinisher.Models
{
    /// <summary>
    /// Immutable snapshot of a single Revit room as read from the model. This is a plain POCO
    /// with no Revit API references so it can travel freely between the Revit thread and the WPF
    /// UI thread. The <see cref="ViewModels.RoomViewModel"/> wraps one of these and keeps it as
    /// the "original" baseline used for dirty-tracking and Undo.
    /// </summary>
    public sealed class RoomData
    {
        /// <summary>
        /// Revit ElementId value. Stored as a long because Revit 2024+ uses 64-bit element ids.
        /// We keep the primitive (not an ElementId) so this object stays API-free.
        /// </summary>
        public long ElementIdValue { get; set; }

        public string Number { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;

        /// <summary>Level name (read-only in the UI).</summary>
        public string Level { get; set; } = string.Empty;

        public string Department { get; set; } = string.Empty;
        public string WallFinish { get; set; } = string.Empty;
        public string FloorFinish { get; set; } = string.Empty;
        public string CeilingFinish { get; set; } = string.Empty;
        public string BaseFinish { get; set; } = string.Empty;

        /// <summary>
        /// Ceiling height as a display-unit string (e.g. "3000" mm or "9'-10\""). Empty when the
        /// configured parameter does not exist on the room or has no value.
        /// </summary>
        public string CeilingHeight { get; set; } = string.Empty;

        /// <summary>
        /// True when the configured Ceiling Height parameter exists and is writable on this room.
        /// When false the UI shows the cell as read-only/blank rather than inventing a value.
        /// </summary>
        public bool CeilingHeightSupported { get; set; }

        /// <summary>
        /// False for unplaced / unenclosed rooms (Location == null or Area == 0). Such rooms are
        /// shown but excluded from the commit by default.
        /// </summary>
        public bool IsPlaced { get; set; } = true;

        /// <summary>Creates an independent copy (used so the ViewModel can mutate without touching the baseline).</summary>
        public RoomData Clone()
        {
            return new RoomData
            {
                ElementIdValue = ElementIdValue,
                Number = Number,
                Name = Name,
                Level = Level,
                Department = Department,
                WallFinish = WallFinish,
                FloorFinish = FloorFinish,
                CeilingFinish = CeilingFinish,
                BaseFinish = BaseFinish,
                CeilingHeight = CeilingHeight,
                CeilingHeightSupported = CeilingHeightSupported,
                IsPlaced = IsPlaced
            };
        }
    }
}
