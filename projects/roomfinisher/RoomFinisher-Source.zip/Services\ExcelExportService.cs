using System.Collections.Generic;
using System.IO;
using ClosedXML.Excel;
using RoomFinisher.Models;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Services
{
    /// <summary>
    /// Exports data to .xlsx using ClosedXML (formatted header, frozen top row, auto-fit columns)
    /// and to .csv for the quality report. IO failures bubble up so the caller can show a friendly
    /// "file locked / no permission" message.
    /// </summary>
    public sealed class ExcelExportService
    {
        private static readonly string[] RoomHeaders =
        {
            "Room Number", "Room Name", "Level", "Department",
            "Wall Finish", "Floor Finish", "Ceiling Finish", "Ceiling Height", "Base Finish"
        };

        /// <summary>
        /// Exports the supplied (already-filtered, already-ordered) rooms to an .xlsx worksheet whose
        /// columns mirror the on-screen DataGrid exactly. Returns the number of rows written.
        /// </summary>
        public int ExportRooms(IEnumerable<RoomViewModel> rooms, string path)
        {
            using (var workbook = new XLWorkbook())
            {
                var ws = workbook.Worksheets.Add("Rooms");

                // Header row.
                for (int c = 0; c < RoomHeaders.Length; c++)
                    ws.Cell(1, c + 1).Value = RoomHeaders[c];

                var header = ws.Row(1);
                header.Style.Font.Bold = true;
                header.Style.Fill.BackgroundColor = XLColor.FromHtml("#EEF2F6");

                int row = 2;
                foreach (var r in rooms)
                {
                    ws.Cell(row, 1).Value = r.Number;
                    ws.Cell(row, 2).Value = r.Name;
                    ws.Cell(row, 3).Value = r.Level;
                    ws.Cell(row, 4).Value = r.Department;
                    ws.Cell(row, 5).Value = r.WallFinish;
                    ws.Cell(row, 6).Value = r.FloorFinish;
                    ws.Cell(row, 7).Value = r.CeilingFinish;
                    ws.Cell(row, 8).Value = r.CeilingHeight;
                    ws.Cell(row, 9).Value = r.BaseFinish;
                    row++;
                }

                ws.SheetView.FreezeRows(1);     // freeze the top (header) row
                ws.Columns().AdjustToContents(); // auto-fit

                workbook.SaveAs(path);
                return row - 2;
            }
        }

        /// <summary>Exports quality issues to .xlsx.</summary>
        public int ExportQualityIssues(IEnumerable<QualityIssue> issues, string path)
        {
            using (var workbook = new XLWorkbook())
            {
                var ws = workbook.Worksheets.Add("Quality Issues");
                string[] headers = { "Severity", "Issue", "Room", "Field", "Suggestion" };
                for (int c = 0; c < headers.Length; c++)
                    ws.Cell(1, c + 1).Value = headers[c];

                var header = ws.Row(1);
                header.Style.Font.Bold = true;
                header.Style.Fill.BackgroundColor = XLColor.FromHtml("#EEF2F6");

                int row = 2;
                foreach (var i in issues)
                {
                    ws.Cell(row, 1).Value = i.Severity.ToString();
                    ws.Cell(row, 2).Value = i.Issue;
                    ws.Cell(row, 3).Value = i.RoomNumber;
                    ws.Cell(row, 4).Value = i.Field;
                    ws.Cell(row, 5).Value = i.Suggestion;
                    row++;
                }

                ws.SheetView.FreezeRows(1);
                ws.Columns().AdjustToContents();
                workbook.SaveAs(path);
                return row - 2;
            }
        }

        /// <summary>Exports quality issues to a simple CSV file.</summary>
        public int ExportQualityIssuesCsv(IEnumerable<QualityIssue> issues, string path)
        {
            using (var writer = new StreamWriter(path, false, System.Text.Encoding.UTF8))
            {
                writer.WriteLine("Severity,Issue,Room,Field,Suggestion");
                int count = 0;
                foreach (var i in issues)
                {
                    writer.WriteLine(string.Join(",",
                        Csv(i.Severity.ToString()),
                        Csv(i.Issue),
                        Csv(i.RoomNumber),
                        Csv(i.Field),
                        Csv(i.Suggestion)));
                    count++;
                }
                return count;
            }
        }

        /// <summary>Quotes a CSV field and escapes embedded quotes.</summary>
        private static string Csv(string value)
        {
            value ??= string.Empty;
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        }
    }
}
