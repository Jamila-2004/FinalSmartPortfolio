using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Input;
using RoomFinisher.Helpers;
using RoomFinisher.Models;
using RoomFinisher.Services;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// The application's central ViewModel. Owns the room collection, the filtered/sorted/grouped
    /// view, the toolbar commands, statistics and status text, and orchestrates every service.
    /// Contains no Revit API calls - all model access goes through <see cref="IRevitWorker"/>; all
    /// windows go through <see cref="IDialogService"/>.
    /// </summary>
    public sealed class MainViewModel : ViewModelBase
    {
        private readonly IRevitWorker _worker;
        private readonly IDialogService _dialogs;
        private readonly AppSettings _settings;
        private readonly string _documentTitle;

        // Pure services.
        private readonly UndoService _undo = new UndoService();
        private readonly FinishOptionsProvider _options = new FinishOptionsProvider();
        private readonly BulkEditService _bulkEdit = new BulkEditService();
        private readonly ChangeTrackingService _changeTracking = new ChangeTrackingService();
        private readonly AnalyticsService _analyticsService = new AnalyticsService();
        private readonly QualityCheckService _qualityService = new QualityCheckService();
        private readonly ExcelExportService _excel = new ExcelExportService();
        private readonly TemplateService _templates = new TemplateService();
        private readonly AuditLogService _audit = new AuditLogService();
        private readonly AiFinishService _aiService = new AiFinishService();

        // Max rooms per AI request (keeps token usage and latency reasonable).
        private const int MaxAiRooms = 80;

        private readonly ICollectionView _roomsView;

        // Live analytics VM kept so an open Analytics window updates as the user edits.
        private AnalyticsViewModel _analyticsViewModel;

        private string _searchText = string.Empty;
        private bool _searchByName = true;
        private bool _searchByNumber = true;
        private bool _searchByDepartment;
        private string _statusText = "Ready";
        private bool _isBusy;

        public MainViewModel(
            IList<RoomData> initialRooms,
            IRevitWorker worker,
            IDialogService dialogs,
            AppSettings settings,
            string documentTitle)
        {
            _worker = worker;
            _dialogs = dialogs;
            _settings = settings ?? new AppSettings();
            _documentTitle = documentTitle ?? string.Empty;

            Rooms = new ObservableCollection<RoomViewModel>();
            LevelFilters = new ObservableCollection<LevelFilterItem>();

            // Bindable options for the editable finish combo-boxes.
            WallFinishOptions = _options.WallFinishes;
            FloorFinishOptions = _options.FloorFinishes;
            CeilingFinishOptions = _options.CeilingFinishes;
            BaseFinishOptions = _options.BaseFinishes;

            LoadRooms(initialRooms ?? new List<RoomData>());

            // CollectionViewSource-backed view drives filtering + sorting + grouping in the grid.
            _roomsView = CollectionViewSource.GetDefaultView(Rooms);
            _roomsView.Filter = FilterRoom;
            _roomsView.SortDescriptions.Add(new SortDescription(nameof(RoomViewModel.Level), ListSortDirection.Ascending));
            // Group by level so the grid shows collapsible "Level: X (n)" headers.
            _roomsView.GroupDescriptions.Add(new PropertyGroupDescription(nameof(RoomViewModel.Level)));

            // Commands.
            RefreshCommand = new RelayCommand(Refresh, () => !IsBusy);
            ApplyChangesCommand = new RelayCommand(ApplyChanges, () => !IsBusy && ModifiedRooms > 0);
            UndoCommand = new RelayCommand(UndoLast, () => !IsBusy && _undo.CanUndo);
            SaveTemplateCommand = new RelayCommand(SaveTemplate, () => !IsBusy);
            LoadTemplateCommand = new RelayCommand(LoadTemplate, () => !IsBusy);
            ExportExcelCommand = new RelayCommand(ExportExcel, () => !IsBusy);
            AnalyticsCommand = new RelayCommand(ShowAnalytics, () => !IsBusy);
            DetectIssuesCommand = new RelayCommand(DetectIssues, () => !IsBusy);
            BulkEditCommand = new RelayCommand(BulkEdit, () => !IsBusy);
            ShowInRevitCommand = new RelayCommand(ShowInRevit, () => !IsBusy);
            ClearLevelFiltersCommand = new RelayCommand(ClearLevelFilters);
            AiAssistCommand = new RelayCommand(AiAssist, () => !IsBusy);
            AiSettingsCommand = new RelayCommand(OpenAiSettings, () => !IsBusy);
        }

        // ---- Bound collections ---------------------------------------------------------------
        public ObservableCollection<RoomViewModel> Rooms { get; }
        public ICollectionView RoomsView => _roomsView;

        /// <summary>Checkable levels for the multi-select level filter.</summary>
        public ObservableCollection<LevelFilterItem> LevelFilters { get; }

        public ObservableCollection<string> WallFinishOptions { get; }
        public ObservableCollection<string> FloorFinishOptions { get; }
        public ObservableCollection<string> CeilingFinishOptions { get; }
        public ObservableCollection<string> BaseFinishOptions { get; }

        /// <summary>Selected rows, pushed in from the View's SelectionChanged handler (plumbing only).</summary>
        public IList SelectedRooms { get; set; }

        // ---- Search / filter -----------------------------------------------------------------
        public string SearchText
        {
            get => _searchText;
            set { if (SetProperty(ref _searchText, value)) RefreshFilter(); }
        }

        public bool SearchByName
        {
            get => _searchByName;
            set { if (SetProperty(ref _searchByName, value)) RefreshFilter(); }
        }

        public bool SearchByNumber
        {
            get => _searchByNumber;
            set { if (SetProperty(ref _searchByNumber, value)) RefreshFilter(); }
        }

        public bool SearchByDepartment
        {
            get => _searchByDepartment;
            set { if (SetProperty(ref _searchByDepartment, value)) RefreshFilter(); }
        }

        /// <summary>Text shown on the level-filter dropdown button.</summary>
        public string LevelFilterSummary
        {
            get
            {
                var selected = LevelFilters.Where(l => l.IsSelected).ToList();
                if (selected.Count == 0 || selected.Count == LevelFilters.Count) return "All Levels";
                if (selected.Count == 1) return selected[0].Name;
                return $"{selected.Count} levels";
            }
        }

        // ---- Status / stats ------------------------------------------------------------------
        public string StatusText
        {
            get => _statusText;
            private set => SetProperty(ref _statusText, value);
        }

        public bool IsBusy
        {
            get => _isBusy;
            private set { if (SetProperty(ref _isBusy, value)) CommandManager.InvalidateRequerySuggested(); }
        }

        public int TotalRooms => Rooms.Count;
        public int VisibleRooms => _roomsView?.Cast<object>().Count() ?? 0;
        public int ModifiedRooms => Rooms.Count(r => r.IsModified);

        /// <summary>Header summary, e.g. "15 modified rooms".</summary>
        public string ModifiedSummary => $"{ModifiedRooms} modified room{(ModifiedRooms == 1 ? "" : "s")}";

        public bool HasModifiedRooms => ModifiedRooms > 0;

        // ---- Commands ------------------------------------------------------------------------
        public ICommand RefreshCommand { get; }
        public ICommand ApplyChangesCommand { get; }
        public ICommand UndoCommand { get; }
        public ICommand SaveTemplateCommand { get; }
        public ICommand LoadTemplateCommand { get; }
        public ICommand ExportExcelCommand { get; }
        public ICommand AnalyticsCommand { get; }
        public ICommand DetectIssuesCommand { get; }
        public ICommand BulkEditCommand { get; }
        public ICommand ShowInRevitCommand { get; }
        public ICommand ClearLevelFiltersCommand { get; }
        public ICommand AiAssistCommand { get; }
        public ICommand AiSettingsCommand { get; }

        // ======================================================================================
        //  Room loading & filtering
        // ======================================================================================

        private void LoadRooms(IList<RoomData> data)
        {
            Rooms.Clear();
            _options.SeedFromRooms(data);

            foreach (var rd in data)
            {
                var vm = new RoomViewModel(rd, _undo, _options);
                vm.ModifiedStateChanged += OnRoomModified;
                Rooms.Add(vm);
            }

            RebuildLevels();
            RaiseStats();
        }

        private void RebuildLevels()
        {
            // Preserve any currently-selected level names across a reload.
            var previouslySelected = LevelFilters.Where(l => l.IsSelected).Select(l => l.Name).ToHashSet();

            LevelFilters.Clear();
            foreach (var lvl in Rooms.Select(r => r.Level)
                                     .Where(l => !string.IsNullOrWhiteSpace(l))
                                     .Distinct()
                                     .OrderBy(l => l))
            {
                var item = new LevelFilterItem(lvl, OnLevelFilterChanged);
                if (previouslySelected.Contains(lvl)) item.IsSelected = true;
                LevelFilters.Add(item);
            }

            RaisePropertyChanged(nameof(LevelFilterSummary));
        }

        private void OnLevelFilterChanged()
        {
            RefreshFilter();
            RaisePropertyChanged(nameof(LevelFilterSummary));
        }

        private void ClearLevelFilters()
        {
            foreach (var item in LevelFilters) item.IsSelected = false;
            // OnLevelFilterChanged fires per toggle; ensure summary refresh.
            RaisePropertyChanged(nameof(LevelFilterSummary));
            RefreshFilter();
        }

        private bool FilterRoom(object obj)
        {
            if (!(obj is RoomViewModel room)) return false;

            // Level filter: empty selection means "all levels".
            var selectedLevels = LevelFilters.Where(l => l.IsSelected).Select(l => l.Name).ToList();
            if (selectedLevels.Count > 0 && !selectedLevels.Contains(room.Level))
            {
                return false;
            }

            return SearchService.Matches(room, SearchText, SearchByName, SearchByNumber, SearchByDepartment);
        }

        private void RefreshFilter()
        {
            _roomsView?.Refresh();
            RaisePropertyChanged(nameof(VisibleRooms));
        }

        private void OnRoomModified(object sender, EventArgs e)
        {
            RaiseStats();
            _analyticsViewModel?.Update(Rooms); // live analytics refresh
        }

        private void RaiseStats()
        {
            RaisePropertyChanged(nameof(TotalRooms));
            RaisePropertyChanged(nameof(VisibleRooms));
            RaisePropertyChanged(nameof(ModifiedRooms));
            RaisePropertyChanged(nameof(ModifiedSummary));
            RaisePropertyChanged(nameof(HasModifiedRooms));
        }

        // ======================================================================================
        //  Refresh
        // ======================================================================================

        private void Refresh()
        {
            if (ModifiedRooms > 0 &&
                !_dialogs.Confirm("Unsaved Changes",
                    $"You have {ModifiedSummary} that have not been applied to Revit.\n\n" +
                    "Refreshing will discard these local edits and reload from the model. Continue?"))
            {
                return;
            }

            RefreshFromModel(silent: false);
        }

        private void RefreshFromModel(bool silent)
        {
            IsBusy = true;
            StatusText = "Loading…";

            _worker.CollectRooms(
                onDone: rooms =>
                {
                    LoadRooms(rooms);
                    RefreshFilter();
                    _undo.Clear();
                    IsBusy = false;
                    StatusText = "Ready";
                    if (!silent) _dialogs.ShowInfo("Refresh Complete", $"Loaded {rooms.Count} rooms from the model.");
                },
                onError: msg =>
                {
                    IsBusy = false;
                    StatusText = "Ready";
                    _dialogs.ShowError("Refresh Failed", msg);
                });
        }

        // ======================================================================================
        //  Apply changes (validate -> review -> single transaction)
        // ======================================================================================

        private void ApplyChanges()
        {
            if (ModifiedRooms == 0)
            {
                _dialogs.ShowInfo("Nothing to Apply", "There are no modified rooms to apply.");
                return;
            }

            // 1. Validate locally (instant, no Revit calls).
            var issues = ValidationHelper.Validate(Rooms.Where(r => r.IsModified));
            if (issues.Count > 0 && !_dialogs.ShowValidation(issues))
            {
                return; // user chose to go back and fix
            }

            // 2. Review window.
            var records = _changeTracking.BuildChangeRecords(Rooms);
            var reviewVm = new ReviewChangesViewModel(records);
            if (!_dialogs.ShowReview(reviewVm))
            {
                return; // Back / Cancel
            }

            // 3. Commit in a single transaction (on the Revit thread).
            var changeSets = _changeTracking.BuildChangeSets(Rooms);
            if (changeSets.Count == 0)
            {
                _dialogs.ShowInfo("Nothing to Apply", "No applicable parameter changes were found.");
                return;
            }

            IsBusy = true;
            StatusText = "Applying Changes…";

            _worker.ApplyChanges(
                changeSets,
                onDone: result =>
                {
                    _audit.LogCommit(_documentTitle, result);
                    IsBusy = false;
                    StatusText = "Ready";

                    if (!result.TransactionCommitted)
                    {
                        _dialogs.ShowError("Apply Failed",
                            "The Revit transaction could not be completed and was rolled back.\n\n" +
                            (result.FatalError ?? "Unknown error."));
                        return;
                    }

                    ShowCommitSummary(result);

                    // Re-read from the model so the grid reflects exactly what Revit stored
                    // (also normalizes ceiling-height rounding). This clears the modified highlights.
                    RefreshFromModel(silent: true);
                },
                onError: msg =>
                {
                    IsBusy = false;
                    StatusText = "Ready";
                    _dialogs.ShowError("Apply Failed", msg);
                });
        }

        private void ShowCommitSummary(CommitResult result)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Updated: {result.Updated} rooms");
            sb.AppendLine($"Failed: {result.Failed} rooms");

            if (result.Failed > 0)
            {
                sb.AppendLine();
                sb.AppendLine("Failure details:");
                foreach (var f in result.Failures.Take(25))
                {
                    sb.AppendLine($"  • Room {f.RoomNumber} ({f.RoomName}): {f.Reason}");
                }
                if (result.Failures.Count > 25)
                    sb.AppendLine($"  … and {result.Failures.Count - 25} more.");
            }

            if (result.Failed > 0) _dialogs.ShowError("Apply Complete (with failures)", sb.ToString());
            else _dialogs.ShowInfo("Apply Complete", sb.ToString());
        }

        // ======================================================================================
        //  Show in Revit (select + zoom the active view to the selected rooms)
        // ======================================================================================

        private void ShowInRevit()
        {
            var selected = SelectedRoomList();
            if (selected.Count == 0)
            {
                _dialogs.ShowInfo("Show in Revit", "Select one or more rooms first.");
                return;
            }

            var ids = selected.Select(r => r.ElementIdValue).ToList();
            IsBusy = true;
            StatusText = "Locating in Revit…";

            _worker.ShowInRevit(
                ids,
                onDone: () => { IsBusy = false; StatusText = "Ready"; },
                onError: msg => { IsBusy = false; StatusText = "Ready"; _dialogs.ShowError("Show in Revit", msg); });
        }

        // ======================================================================================
        //  Undo (local, pre-commit)
        // ======================================================================================

        private void UndoLast()
        {
            _undo.Undo();
            RaiseStats();
            _analyticsViewModel?.Update(Rooms);
        }

        // ======================================================================================
        //  Templates
        // ======================================================================================

        private void SaveTemplate()
        {
            var source = FirstSelectedRoom();
            if (source == null)
            {
                _dialogs.ShowInfo("Save Template",
                    "Select a room first - its current finishes will be captured into the template.");
                return;
            }

            var path = _dialogs.SaveFile("JSON Template (*.json)|*.json", "Finish_Template.json", _settings.LastTemplateFolder);
            if (string.IsNullOrEmpty(path)) return;

            var template = new FinishTemplate
            {
                Name = Path.GetFileNameWithoutExtension(path),
                WallFinish = source.WallFinish,
                FloorFinish = source.FloorFinish,
                CeilingFinish = source.CeilingFinish,
                BaseFinish = source.BaseFinish,
                CeilingHeight = source.CeilingHeight
            };

            try
            {
                StatusText = "Saving…";
                _templates.Save(template, path);
                _settings.LastTemplateFolder = Path.GetDirectoryName(path);
                _settings.Save();
                _dialogs.ShowInfo("Template Saved", $"Template saved to:\n{path}");
            }
            catch (Exception ex)
            {
                _dialogs.ShowError("Save Failed", FriendlyIoMessage(ex, path));
            }
            finally
            {
                StatusText = "Ready";
            }
        }

        private void LoadTemplate()
        {
            var path = _dialogs.OpenFile("JSON Template (*.json)|*.json", _settings.LastTemplateFolder);
            if (string.IsNullOrEmpty(path)) return;

            FinishTemplate template;
            try
            {
                template = _templates.Load(path);
                _settings.LastTemplateFolder = Path.GetDirectoryName(path);
                _settings.Save();
            }
            catch (Exception ex)
            {
                _dialogs.ShowError("Load Failed", FriendlyIoMessage(ex, path));
                return;
            }

            var departments = Rooms.Select(r => r.Department)
                                   .Where(d => !string.IsNullOrWhiteSpace(d))
                                   .Distinct()
                                   .OrderBy(d => d)
                                   .ToList();

            var applyVm = new ApplyTemplateViewModel(
                template, Rooms, SelectedRoomList(), departments, _changeTracking);

            if (_dialogs.ShowApplyTemplate(applyVm))
            {
                RaiseStats();
                _analyticsViewModel?.Update(Rooms);
            }
        }

        // ======================================================================================
        //  Excel export (visible/filtered rows only)
        // ======================================================================================

        private void ExportExcel()
        {
            var visible = _roomsView.Cast<RoomViewModel>().ToList();
            if (visible.Count == 0)
            {
                _dialogs.ShowInfo("Export to Excel", "There are no visible rooms to export.");
                return;
            }

            var path = _dialogs.SaveFile("Excel Workbook (*.xlsx)|*.xlsx", "Room_Finishes.xlsx", _settings.LastTemplateFolder);
            if (string.IsNullOrEmpty(path)) return;

            try
            {
                StatusText = "Saving…";
                int count = _excel.ExportRooms(visible, path);
                _dialogs.ShowInfo("Export Complete", $"{count} rooms exported successfully.\n\n{path}");
            }
            catch (Exception ex)
            {
                _dialogs.ShowError("Export Failed", FriendlyIoMessage(ex, path));
            }
            finally
            {
                StatusText = "Ready";
            }
        }

        // ======================================================================================
        //  Analytics
        // ======================================================================================

        private void ShowAnalytics()
        {
            _analyticsViewModel = new AnalyticsViewModel(_analyticsService);
            _analyticsViewModel.Update(Rooms);
            _dialogs.ShowAnalytics(_analyticsViewModel);
        }

        // ======================================================================================
        //  Quality check
        // ======================================================================================

        private void DetectIssues()
        {
            var report = _qualityService.Run(Rooms);
            var vm = new QualityReportViewModel(report, _excel, _dialogs, FocusRoom);
            _dialogs.ShowQualityReport(vm);
        }

        /// <summary>"Fix Selected" target: clear filters and search to the offending room number.</summary>
        private void FocusRoom(long elementIdValue)
        {
            var room = Rooms.FirstOrDefault(r => r.ElementIdValue == elementIdValue);
            if (room == null) return;

            // Make sure the room is visible regardless of current level filter.
            foreach (var item in LevelFilters) item.IsSelected = false;
            SearchByNumber = true;
            SearchText = room.Number;
            RefreshFilter();
            RaisePropertyChanged(nameof(LevelFilterSummary));
        }

        // ======================================================================================
        //  Bulk edit
        // ======================================================================================

        private void BulkEdit()
        {
            var selected = SelectedRoomList();
            if (selected.Count == 0)
            {
                _dialogs.ShowInfo("Bulk Edit", "Select one or more rooms first.");
                return;
            }

            var vm = new BulkEditViewModel(_options, selected, _bulkEdit);
            if (_dialogs.ShowBulkEdit(vm))
            {
                RaiseStats();
                _analyticsViewModel?.Update(Rooms);
            }
        }

        // ======================================================================================
        //  AI Finish Assistant (suggest -> approve -> normal commit)
        // ======================================================================================

        private void OpenAiSettings()
        {
            _dialogs.ShowAiSettings(new AiSettingsViewModel(_settings));
        }

        private async void AiAssist()
        {
            // Ensure we have an API key (prompt for it the first time).
            if (string.IsNullOrWhiteSpace(_settings.ActiveApiKey))
            {
                var keyVm = new AiSettingsViewModel(_settings);
                if (!_dialogs.ShowAiSettings(keyVm) || string.IsNullOrWhiteSpace(_settings.ActiveApiKey))
                {
                    return;
                }
            }

            // Target the selected rooms, or all rooms if nothing is selected.
            var targets = SelectedRoomList();
            if (targets.Count == 0) targets = Rooms.ToList();

            if (targets.Count == 0)
            {
                _dialogs.ShowInfo("AI Finish Assistant", "There are no rooms to analyze.");
                return;
            }

            if (targets.Count > MaxAiRooms)
            {
                _dialogs.ShowInfo("AI Finish Assistant",
                    $"Please select up to {MaxAiRooms} rooms for one AI run (you targeted {targets.Count}). " +
                    "Select a subset and try again.");
                return;
            }

            IsBusy = true;
            StatusText = "Asking AI…";

            try
            {
                var result = await _aiService.SuggestAsync(targets, _options, _settings);

                IsBusy = false;
                StatusText = "Ready";

                if (result.Changes.Count == 0 && result.Notes.Count == 0)
                {
                    _dialogs.ShowInfo("AI Finish Assistant", "The AI had no suggestions for these rooms.");
                    return;
                }

                // The approval window is the "ask before changing" gate.
                var vm = new AiSuggestionsViewModel(result);
                if (_dialogs.ShowAiSuggestions(vm))
                {
                    foreach (var change in vm.AcceptedChanges)
                    {
                        var room = Rooms.FirstOrDefault(r => r.ElementIdValue == change.ElementIdValue);
                        room?.SetFieldValue(change.Field, change.SuggestedValue);
                    }
                    RaiseStats();
                    _analyticsViewModel?.Update(Rooms);
                }
            }
            catch (Exception ex)
            {
                IsBusy = false;
                StatusText = "Ready";
                _dialogs.ShowError("AI Finish Assistant", ex.Message);
            }
        }

        // ======================================================================================
        //  Helpers
        // ======================================================================================

        private List<RoomViewModel> SelectedRoomList()
        {
            if (SelectedRooms == null) return new List<RoomViewModel>();
            return SelectedRooms.Cast<object>().OfType<RoomViewModel>().ToList();
        }

        private RoomViewModel FirstSelectedRoom() => SelectedRoomList().FirstOrDefault();

        private static string FriendlyIoMessage(Exception ex, string path)
        {
            if (ex is UnauthorizedAccessException)
                return $"You do not have permission to write to:\n{path}\n\nTry a different folder.";
            if (ex is IOException)
                return $"The file may be open in another program or locked:\n{path}\n\nClose it and try again.\n\nDetails: {ex.Message}";
            if (ex is DirectoryNotFoundException)
                return $"The folder for this path does not exist:\n{path}";
            return $"Could not complete the operation.\n\nDetails: {ex.Message}";
        }
    }
}
