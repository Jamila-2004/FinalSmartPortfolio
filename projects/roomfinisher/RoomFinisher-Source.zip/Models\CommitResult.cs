using System.Collections.Generic;

namespace RoomFinisher.Models
{
    /// <summary>Details of a single room that could not be updated during commit.</summary>
    public sealed class RoomFailure
    {
        public string RoomNumber { get; set; } = string.Empty;
        public string RoomName { get; set; } = string.Empty;
        public string Reason { get; set; } = string.Empty;
    }

    /// <summary>
    /// Outcome of writing changes back to Revit in a single transaction. Returned from the Revit
    /// thread to the UI so a success/failure summary can be shown
    /// ("Updated: 54 rooms / Failed: 2 rooms").
    /// </summary>
    public sealed class CommitResult
    {
        public int Updated { get; set; }

        public List<RoomFailure> Failures { get; } = new List<RoomFailure>();

        public int Failed => Failures.Count;

        /// <summary>True when the Revit transaction was committed (even if some rooms failed individually).</summary>
        public bool TransactionCommitted { get; set; }

        /// <summary>Set when the whole transaction failed (rolled back). Null on success.</summary>
        public string FatalError { get; set; }
    }
}
