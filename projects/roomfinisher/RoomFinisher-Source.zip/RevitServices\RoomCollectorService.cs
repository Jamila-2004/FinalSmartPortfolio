using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using RoomFinisher.Models;

namespace RoomFinisher.RevitServices
{
    /// <summary>
    /// Reads every room from the active document into API-free <see cref="RoomData"/> snapshots.
    /// Called once on open and again on Refresh, always from a valid Revit API context
    /// (the external command or the ExternalEvent handler).
    /// </summary>
    public sealed class RoomCollectorService
    {
        public List<RoomData> Collect(Document doc, AppSettings settings)
        {
            var rooms = new List<RoomData>();
            if (doc == null) return rooms;

            // FilteredElementCollector is the canonical way to enumerate rooms. We read everything
            // once and never touch the API again until commit (per the performance requirements).
            var collector = new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_Rooms)
                .WhereElementIsNotElementType();

            foreach (var element in collector)
            {
                if (!(element is Room room)) continue;

                var data = new RoomData
                {
                    ElementIdValue = room.Id.Value,                 // 64-bit element id (Revit 2024+)
                    Number = RoomParameterService.GetString(room, RoomField.Number),
                    Name = RoomParameterService.GetString(room, RoomField.Name),
                    Department = RoomParameterService.GetString(room, RoomField.Department),
                    WallFinish = RoomParameterService.GetString(room, RoomField.WallFinish),
                    FloorFinish = RoomParameterService.GetString(room, RoomField.FloorFinish),
                    CeilingFinish = RoomParameterService.GetString(room, RoomField.CeilingFinish),
                    BaseFinish = RoomParameterService.GetString(room, RoomField.BaseFinish),
                    Level = RoomParameterService.GetLevelName(doc, room),
                    // Unplaced / unenclosed rooms have no location or zero area; we still show them
                    // but exclude them from commit by default.
                    IsPlaced = room.Location != null && room.Area > 0
                };

                data.CeilingHeight = RoomParameterService.GetCeilingHeight(
                    room, settings.CeilingHeightParameterName, out var supported);
                data.CeilingHeightSupported = supported;

                rooms.Add(data);
            }

            // Group/sort by level then room number for a schedule-like ordering.
            return rooms
                .OrderBy(r => r.Level)
                .ThenBy(r => r.Number, new NaturalNumberComparer())
                .ToList();
        }

        /// <summary>
        /// Sorts room numbers so "2" precedes "10" (natural order), falling back to ordinal for
        /// non-numeric numbers like "A-101".
        /// </summary>
        private sealed class NaturalNumberComparer : IComparer<string>
        {
            public int Compare(string x, string y)
            {
                bool xn = int.TryParse(x, out var xi);
                bool yn = int.TryParse(y, out var yi);
                if (xn && yn) return xi.CompareTo(yi);
                return string.Compare(x ?? "", y ?? "", System.StringComparison.OrdinalIgnoreCase);
            }
        }
    }
}
