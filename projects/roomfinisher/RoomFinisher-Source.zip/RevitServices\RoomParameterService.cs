using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using RoomFinisher.Models;

namespace RoomFinisher.RevitServices
{
    /// <summary>
    /// The single place that knows how each <see cref="RoomField"/> maps onto a Revit parameter,
    /// and how to read/write it safely (handling missing params, read-only params and units).
    ///
    /// Native built-in parameters are used for everything except Ceiling Height, which Revit does
    /// not expose natively on rooms - that one is resolved by name from the configured
    /// project/shared parameter (see <see cref="AppSettings.CeilingHeightParameterName"/>).
    /// </summary>
    public static class RoomParameterService
    {
        // Field -> built-in parameter. Level is intentionally absent (read-only display only),
        // as is CeilingHeight (resolved by name).
        private static readonly Dictionary<RoomField, BuiltInParameter> BuiltInMap =
            new Dictionary<RoomField, BuiltInParameter>
            {
                { RoomField.Number,        BuiltInParameter.ROOM_NUMBER },
                { RoomField.Name,          BuiltInParameter.ROOM_NAME },
                { RoomField.Department,    BuiltInParameter.ROOM_DEPARTMENT },
                { RoomField.WallFinish,    BuiltInParameter.ROOM_FINISH_WALL },
                { RoomField.FloorFinish,   BuiltInParameter.ROOM_FINISH_FLOOR },
                { RoomField.CeilingFinish, BuiltInParameter.ROOM_FINISH_CEILING },
                { RoomField.BaseFinish,    BuiltInParameter.ROOM_FINISH_BASE },
            };

        // ---- READ ----------------------------------------------------------------------------

        /// <summary>Reads a text-valued built-in field. Returns "" when the parameter is missing/empty.</summary>
        public static string GetString(Room room, RoomField field)
        {
            if (!BuiltInMap.TryGetValue(field, out var bip)) return string.Empty;
            var p = room.get_Parameter(bip);
            return p?.AsString() ?? string.Empty;
        }

        /// <summary>Resolves the level name for a room (read-only in the UI).</summary>
        public static string GetLevelName(Document doc, Room room)
        {
            try
            {
                var lvl = doc.GetElement(room.LevelId) as Level;
                return lvl?.Name ?? string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Reads the configured Ceiling Height parameter as a display-unit string.
        /// <paramref name="supported"/> is true only when the parameter exists, is a length, and is
        /// writable; otherwise the UI shows the cell blank/read-only rather than fabricating a value.
        /// </summary>
        public static string GetCeilingHeight(Room room, string paramName, out bool supported)
        {
            supported = false;
            if (string.IsNullOrWhiteSpace(paramName)) return string.Empty;

            var p = room.LookupParameter(paramName);
            if (p == null || p.StorageType != StorageType.Double) return string.Empty;

            // Supported for editing only if not read-only.
            supported = !p.IsReadOnly;

            if (!p.HasValue) return string.Empty;

            // AsValueString formats using the document's length units (handles mm, m, feet-inches...).
            return p.AsValueString() ?? string.Empty;
        }

        // ---- WRITE ---------------------------------------------------------------------------

        /// <summary>
        /// Writes one field. Throws an <see cref="InvalidOperationException"/> with a user-friendly
        /// message on any failure (missing/read-only param, unparseable value). The caller catches
        /// this per-room so one bad value never aborts the whole commit.
        /// </summary>
        public static void SetField(Room room, RoomField field, string value, string ceilingParamName)
        {
            if (field == RoomField.CeilingHeight)
            {
                SetCeilingHeight(room, ceilingParamName, value);
                return;
            }

            if (field == RoomField.Level)
                throw new InvalidOperationException("Level is read-only.");

            if (!BuiltInMap.TryGetValue(field, out var bip))
                throw new InvalidOperationException($"No mapping for {field.ToDisplayName()}.");

            var p = room.get_Parameter(bip);
            if (p == null)
                throw new InvalidOperationException($"Parameter '{field.ToDisplayName()}' not found on this room.");
            if (p.IsReadOnly)
                throw new InvalidOperationException($"'{field.ToDisplayName()}' is read-only.");

            p.Set(value ?? string.Empty);
        }

        private static void SetCeilingHeight(Room room, string paramName, string value)
        {
            if (string.IsNullOrWhiteSpace(paramName))
                throw new InvalidOperationException("No Ceiling Height parameter is configured.");

            var p = room.LookupParameter(paramName);
            if (p == null)
                throw new InvalidOperationException($"Ceiling Height parameter '{paramName}' not found in this model.");
            if (p.StorageType != StorageType.Double)
                throw new InvalidOperationException($"Ceiling Height parameter '{paramName}' is not a length.");
            if (p.IsReadOnly)
                throw new InvalidOperationException($"Ceiling Height parameter '{paramName}' is read-only.");

            // SetValueString parses the display string using the document's units; false = unparseable.
            if (!p.SetValueString(value ?? string.Empty))
                throw new InvalidOperationException($"Could not interpret ceiling height '{value}'.");
        }
    }
}
