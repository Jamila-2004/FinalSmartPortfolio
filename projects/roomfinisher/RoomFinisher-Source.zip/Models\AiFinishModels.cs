using System.Collections.Generic;

namespace RoomFinisher.Models
{
    /// <summary>
    /// One AI-proposed finish change for a room. Carries the current value and the suggested value
    /// plus a short rationale (which blends function-suitability reasoning with the fill suggestion).
    /// <see cref="Accept"/> is toggled by the user in the approval window - nothing is written unless
    /// the user accepts it and then runs the normal commit.
    /// </summary>
    public sealed class AiFinishChange
    {
        public long ElementIdValue { get; set; }
        public string RoomNumber { get; set; } = string.Empty;
        public string RoomName { get; set; } = string.Empty;

        public RoomField Field { get; set; }
        public string CurrentValue { get; set; } = string.Empty;
        public string SuggestedValue { get; set; } = string.Empty;
        public string Reason { get; set; } = string.Empty;

        /// <summary>User decision - default accepted, can be unticked. Plain property (two-way bound checkbox).</summary>
        public bool Accept { get; set; } = true;

        /// <summary>Display name of the field, e.g. "Wall Finish".</summary>
        public string FieldDisplay => Field.ToDisplayName();
    }

    /// <summary>The full result of an AI suggestion run: per-room changes plus any general notes.</summary>
    public sealed class AiFinishResult
    {
        public List<AiFinishChange> Changes { get; set; } = new List<AiFinishChange>();

        /// <summary>Model-level observations that aren't tied to a single change.</summary>
        public List<string> Notes { get; set; } = new List<string>();
    }
}
