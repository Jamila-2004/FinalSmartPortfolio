using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using RoomFinisher.Models;
using RoomFinisher.Services;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// One pie slice, drawn as a WPF <see cref="Geometry"/> with a fill brush. Built entirely from
    /// System.Windows.Media primitives - no charting library (which previously crashed Revit).
    /// </summary>
    public sealed class PieSliceVm
    {
        public Geometry Geometry { get; set; }
        public Brush Fill { get; set; }
        public string Name { get; set; }
        public int Count { get; set; }
        public double Percentage { get; set; }
        public string CountLabel => $"{Count}  ({Percentage:0.#}%)";
    }

    /// <summary>
    /// Backs the Analytics window. Builds finish distributions (counts + percentages), a pure-WPF
    /// pie chart for each finish type, and - most importantly for BIM coordination - a
    /// schedule-completeness measure (how many finishes are actually specified). Exposes
    /// <see cref="Update"/> so MainViewModel can refresh it live after edits.
    /// </summary>
    public sealed class AnalyticsViewModel : ViewModelBase
    {
        private const double PieRadius = 80.0;
        private const string NoneKey = "(none)";          // bucket name from AnalyticsService
        private const string NoneLabel = "Not specified"; // shown to the user

        // Categorical palette for real finishes. "Not specified" always uses a muted grey (below).
        private static readonly Color[] Palette =
        {
            Color.FromRgb(0x2D, 0x7D, 0xD2), Color.FromRgb(0xF5, 0x9E, 0x0B),
            Color.FromRgb(0x2E, 0xA0, 0x43), Color.FromRgb(0xD3, 0x2F, 0x2F),
            Color.FromRgb(0x8E, 0x44, 0xAD), Color.FromRgb(0x16, 0xA0, 0x85),
            Color.FromRgb(0xE6, 0x7E, 0x22), Color.FromRgb(0x34, 0x49, 0x5E),
            Color.FromRgb(0xC0, 0x39, 0x2B), Color.FromRgb(0x7F, 0x8C, 0x8D),
        };
        private static readonly Brush NotSpecifiedBrush = Frozen(Color.FromRgb(0xCB, 0xD2, 0xD9));

        private readonly AnalyticsService _service;

        private int _totalRooms;
        private string _scopeText = string.Empty;
        private string _mostCommonWall = "-";
        private string _mostCommonFloor = "-";
        private string _mostCommonCeiling = "-";
        private string _mostCommonBase = "-";

        private double _overallCompleteness;
        private string _overallCompletenessText = "0%";
        private string _wallSpecifiedText = string.Empty;
        private string _floorSpecifiedText = string.Empty;
        private string _ceilingSpecifiedText = string.Empty;
        private string _baseSpecifiedText = string.Empty;

        private IReadOnlyList<PieSliceVm> _wallPie = new List<PieSliceVm>();
        private IReadOnlyList<PieSliceVm> _floorPie = new List<PieSliceVm>();
        private IReadOnlyList<PieSliceVm> _ceilingPie = new List<PieSliceVm>();
        private IReadOnlyList<PieSliceVm> _basePie = new List<PieSliceVm>();

        public AnalyticsViewModel(AnalyticsService service)
        {
            _service = service;
        }

        public int TotalRooms { get => _totalRooms; private set => SetProperty(ref _totalRooms, value); }
        public string ScopeText { get => _scopeText; private set => SetProperty(ref _scopeText, value); }

        public string MostCommonWall { get => _mostCommonWall; private set => SetProperty(ref _mostCommonWall, value); }
        public string MostCommonFloor { get => _mostCommonFloor; private set => SetProperty(ref _mostCommonFloor, value); }
        public string MostCommonCeiling { get => _mostCommonCeiling; private set => SetProperty(ref _mostCommonCeiling, value); }
        public string MostCommonBase { get => _mostCommonBase; private set => SetProperty(ref _mostCommonBase, value); }

        /// <summary>Overall share of finish fields that are specified (0-100), for the KPI + progress bar.</summary>
        public double OverallCompleteness { get => _overallCompleteness; private set => SetProperty(ref _overallCompleteness, value); }
        public string OverallCompletenessText { get => _overallCompletenessText; private set => SetProperty(ref _overallCompletenessText, value); }

        public string WallSpecifiedText { get => _wallSpecifiedText; private set => SetProperty(ref _wallSpecifiedText, value); }
        public string FloorSpecifiedText { get => _floorSpecifiedText; private set => SetProperty(ref _floorSpecifiedText, value); }
        public string CeilingSpecifiedText { get => _ceilingSpecifiedText; private set => SetProperty(ref _ceilingSpecifiedText, value); }
        public string BaseSpecifiedText { get => _baseSpecifiedText; private set => SetProperty(ref _baseSpecifiedText, value); }

        public IReadOnlyList<PieSliceVm> WallPie { get => _wallPie; private set => SetProperty(ref _wallPie, value); }
        public IReadOnlyList<PieSliceVm> FloorPie { get => _floorPie; private set => SetProperty(ref _floorPie, value); }
        public IReadOnlyList<PieSliceVm> CeilingPie { get => _ceilingPie; private set => SetProperty(ref _ceilingPie, value); }
        public IReadOnlyList<PieSliceVm> BasePie { get => _basePie; private set => SetProperty(ref _basePie, value); }

        /// <summary>Recomputes all analytics from the current rooms (call after every edit).</summary>
        public void Update(IEnumerable<RoomViewModel> rooms)
        {
            var data = _service.Build(rooms);

            TotalRooms = data.TotalRooms;
            ScopeText = $"Based on all {data.TotalRooms} room{(data.TotalRooms == 1 ? "" : "s")} in the model";

            MostCommonWall = data.MostCommonWall;
            MostCommonFloor = data.MostCommonFloor;
            MostCommonCeiling = data.MostCommonCeiling;
            MostCommonBase = data.MostCommonBase;

            WallPie = BuildPie(data.WallFinishes);
            FloorPie = BuildPie(data.FloorFinishes);
            CeilingPie = BuildPie(data.CeilingFinishes);
            BasePie = BuildPie(data.BaseFinishes);

            // Schedule completeness - the QA story for a BIM coordinator.
            int total = data.TotalRooms;
            WallSpecifiedText = SpecifiedText(data.WallFinishes, total);
            FloorSpecifiedText = SpecifiedText(data.FloorFinishes, total);
            CeilingSpecifiedText = SpecifiedText(data.CeilingFinishes, total);
            BaseSpecifiedText = SpecifiedText(data.BaseFinishes, total);

            int specifiedFields =
                Specified(data.WallFinishes) + Specified(data.FloorFinishes) +
                Specified(data.CeilingFinishes) + Specified(data.BaseFinishes);
            double overall = total == 0 ? 0 : specifiedFields / (4.0 * total) * 100.0;
            OverallCompleteness = overall;
            OverallCompletenessText = $"{overall:0}%";
        }

        // ---- Completeness helpers ------------------------------------------------------------
        private static int Specified(IReadOnlyList<FinishCount> dist)
            => dist.Where(d => d.Name != NoneKey).Sum(d => d.Count);

        private static string SpecifiedText(IReadOnlyList<FinishCount> dist, int total)
        {
            if (total == 0) return "—";
            double pct = Specified(dist) / (double)total * 100.0;
            return $"{pct:0}% specified";
        }

        // ---- Pie geometry --------------------------------------------------------------------
        private static IReadOnlyList<PieSliceVm> BuildPie(IReadOnlyList<FinishCount> distribution)
        {
            var slices = new List<PieSliceVm>();
            double total = distribution.Sum(d => d.Count);
            if (total <= 0) return slices;

            double centre = PieRadius;
            double startAngle = -90; // start at the top, sweep clockwise
            int colorIndex = 0;      // only advances for real finishes, so "Not specified" stays grey

            if (distribution.Count == 1)
            {
                var only = distribution[0];
                bool none1 = only.Name == NoneKey;
                slices.Add(new PieSliceVm
                {
                    Geometry = new EllipseGeometry(new Point(centre, centre), PieRadius, PieRadius),
                    Fill = none1 ? NotSpecifiedBrush : Swatch(0),
                    Name = none1 ? NoneLabel : only.Name,
                    Count = only.Count,
                    Percentage = only.Percentage
                });
                return slices;
            }

            foreach (var d in distribution)
            {
                bool isNone = d.Name == NoneKey;
                double sweep = d.Count / total * 360.0;
                double endAngle = startAngle + sweep;

                var start = PointOnCircle(centre, PieRadius, startAngle);
                var end = PointOnCircle(centre, PieRadius, endAngle);

                var figure = new PathFigure { StartPoint = new Point(centre, centre), IsClosed = true };
                figure.Segments.Add(new LineSegment(start, true));
                figure.Segments.Add(new ArcSegment(
                    end, new Size(PieRadius, PieRadius), 0, sweep > 180.0, SweepDirection.Clockwise, true));

                var geometry = new PathGeometry();
                geometry.Figures.Add(figure);
                geometry.Freeze();

                slices.Add(new PieSliceVm
                {
                    Geometry = geometry,
                    Fill = isNone ? NotSpecifiedBrush : Swatch(colorIndex++),
                    Name = isNone ? NoneLabel : d.Name,
                    Count = d.Count,
                    Percentage = d.Percentage
                });

                startAngle = endAngle;
            }

            return slices;
        }

        private static Point PointOnCircle(double centre, double radius, double angleDegrees)
        {
            double rad = angleDegrees * Math.PI / 180.0;
            return new Point(centre + radius * Math.Cos(rad), centre + radius * Math.Sin(rad));
        }

        private static Brush Swatch(int index) => Frozen(Palette[index % Palette.Length]);

        private static Brush Frozen(Color color)
        {
            var brush = new SolidColorBrush(color);
            brush.Freeze();
            return brush;
        }
    }
}
