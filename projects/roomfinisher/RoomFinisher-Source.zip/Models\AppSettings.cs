using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace RoomFinisher.Models
{
    /// <summary>
    /// User-configurable settings, persisted as JSON under %APPDATA%\RoomFinisher\settings.json.
    /// The most important setting is the Ceiling Height parameter name: because Revit has no native
    /// room "Ceiling Height" parameter, the user tells us which project/shared parameter to read
    /// and write. If it does not exist on a room, that cell is shown read-only/blank.
    /// </summary>
    public sealed class AppSettings
    {
        /// <summary>Name of the parameter used for the "Ceiling Height" column. Default "Ceiling Height".</summary>
        public string CeilingHeightParameterName { get; set; } = "Ceiling Height";

        /// <summary>Last folder used for templates/exports (quality-of-life only).</summary>
        public string LastTemplateFolder { get; set; } = string.Empty;

        // ---- AI Finish Assistant ----------------------------------------------------------
        // The assistant can use either Google Gemini (free tier available) or Anthropic Claude.
        // Keys are stored locally in settings.json (plain text - documented in the README).

        /// <summary>Active AI provider: "Google" (default) or "Anthropic".</summary>
        public string AiProvider { get; set; } = "Google";

        /// <summary>Google AI Studio (Gemini) API key.</summary>
        public string GoogleApiKey { get; set; } = string.Empty;

        /// <summary>Gemini model id. Defaults to a fast, free-tier-friendly model.</summary>
        public string GoogleModel { get; set; } = "gemini-2.0-flash";

        /// <summary>Anthropic API key.</summary>
        public string AnthropicApiKey { get; set; } = string.Empty;

        /// <summary>Claude model id. Defaults to the current Opus.</summary>
        public string AiModel { get; set; } = "claude-opus-4-8";

        // ---- Convenience accessors (not serialized) ---------------------------------------

        [JsonIgnore]
        public bool IsGoogle => string.Equals(AiProvider, "Google", StringComparison.OrdinalIgnoreCase);

        /// <summary>The API key for the currently selected provider.</summary>
        [JsonIgnore]
        public string ActiveApiKey => IsGoogle ? GoogleApiKey : AnthropicApiKey;

        /// <summary>The model id for the currently selected provider (with a safe default).</summary>
        [JsonIgnore]
        public string ActiveModel => IsGoogle
            ? (string.IsNullOrWhiteSpace(GoogleModel) ? "gemini-2.0-flash" : GoogleModel)
            : (string.IsNullOrWhiteSpace(AiModel) ? "claude-opus-4-8" : AiModel);

        // ---- Persistence ------------------------------------------------------------------

        private static string SettingsDirectory =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "RoomFinisher");

        private static string SettingsPath => Path.Combine(SettingsDirectory, "settings.json");

        /// <summary>Loads settings, falling back to defaults if the file is missing or unreadable.</summary>
        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(SettingsPath))
                {
                    var json = File.ReadAllText(SettingsPath);
                    var loaded = JsonSerializer.Deserialize<AppSettings>(json);
                    if (loaded != null) return loaded;
                }
            }
            catch
            {
                // Corrupt/locked settings should never block the tool; just use defaults.
            }
            return new AppSettings();
        }

        /// <summary>Persists settings; failures are swallowed (non-critical).</summary>
        public void Save()
        {
            try
            {
                Directory.CreateDirectory(SettingsDirectory);
                var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SettingsPath, json);
            }
            catch
            {
                // Ignore - settings persistence is best-effort.
            }
        }
    }
}
