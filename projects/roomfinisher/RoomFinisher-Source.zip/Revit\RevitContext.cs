using System.Windows;

namespace RoomFinisher.Revit
{
    /// <summary>
    /// Process-wide state for the add-in: the single ExternalEvent router (created once, reused for
    /// every request) and the currently open window (so we don't open duplicates). All access is on
    /// the UI thread, so no locking is required.
    /// </summary>
    public static class RevitContext
    {
        /// <summary>The shared request router. Created lazily by the command from a valid API context.</summary>
        public static RevitRequestRouter Router { get; set; }

        /// <summary>The currently open Room Finisher window, or null if closed.</summary>
        public static Window CurrentWindow { get; set; }

        /// <summary>
        /// Ensures a WPF <see cref="Application"/> instance exists. Revit does not create one, but
        /// pack:// resource URIs and Application.Current.Dispatcher require it. Safe to call repeatedly.
        /// </summary>
        public static void EnsureWpfApplication()
        {
            if (Application.Current == null)
            {
                var app = new Application
                {
                    // We must not let closing our window shut down Revit's message loop.
                    ShutdownMode = ShutdownMode.OnExplicitShutdown
                };

                // CRITICAL SAFETY NET: a WPF exception that reaches the dispatcher with no handler
                // will crash the entire Revit process. We swallow it, show a friendly message, and
                // mark it handled so Revit keeps running. We only attach this when WE created the
                // Application (so we don't hijack another add-in's handler).
                app.DispatcherUnhandledException += (sender, e) =>
                {
                    var ex = e.Exception;
                    var details = ex.Message;
                    if (ex.InnerException != null)
                        details += "\n\nInner: " + ex.InnerException.Message;

                    MessageBox.Show(
                        "Room Finisher hit an unexpected error but Revit is safe.\n\n" + details,
                        "Room Finisher - Error",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);

                    e.Handled = true;
                };
            }
        }
    }
}
