using System.Collections.Generic;

namespace RoomFinisher.Models
{
    /// <summary>
    /// A flat, API-free description of the edits to push to ONE room. Built on the UI thread from
    /// a modified <see cref="ViewModels.RoomViewModel"/> and consumed on the Revit thread by
    /// <see cref="RevitServices.RevitTransactionService"/>. Only changed fields are included, so
    /// the transaction writes the minimum number of parameters.
    /// </summary>
    public sealed class RoomChangeSet
    {
        public long ElementIdValue { get; set; }

        /// <summary>For display in failure/summary reports.</summary>
        public string RoomNumber { get; set; } = string.Empty;
        public string RoomName { get; set; } = string.Empty;

        /// <summary>Map of changed field -> new display value.</summary>
        public Dictionary<RoomField, string> ChangedFields { get; } = new Dictionary<RoomField, string>();
    }
}
