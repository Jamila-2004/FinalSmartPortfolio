using System.Windows;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Views
{
    /// <summary>AI Settings dialog (API key + model). Save returns DialogResult true.</summary>
    public partial class AiSettingsWindow : Window
    {
        public AiSettingsWindow(AiSettingsViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
            viewModel.RequestClose += result =>
            {
                DialogResult = result;
                Close();
            };
        }
    }
}
