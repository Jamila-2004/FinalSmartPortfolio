using System;
using System.Windows.Interop;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using RoomFinisher.Models;
using RoomFinisher.Revit;
using RoomFinisher.RevitServices;
using RoomFinisher.ViewModels;
using RoomFinisher.Views;

namespace RoomFinisher.Commands
{
    /// <summary>
    /// The ribbon command. Reads all rooms from the active document (in a valid API context),
    /// builds the MVVM stack and shows the MODELESS main window. After this, every Revit read/write
    /// happens through the ExternalEvent-based <see cref="RevitWorker"/>.
    /// </summary>
    [Transaction(TransactionMode.Manual)]
    public sealed class OpenRoomFinisherCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                var uiApp = commandData.Application;
                var uiDoc = uiApp.ActiveUIDocument;

                if (uiDoc == null || uiDoc.Document == null)
                {
                    TaskDialog.Show("Room Finisher", "Please open a Revit project first.");
                    return Result.Cancelled;
                }

                Document doc = uiDoc.Document;

                // Ensure a WPF Application exists (Revit doesn't create one) so resource URIs and the
                // dispatcher work.
                RevitContext.EnsureWpfApplication();

                // Single-instance: if the window is already open, just bring it forward.
                if (RevitContext.CurrentWindow != null)
                {
                    RevitContext.CurrentWindow.Activate();
                    return Result.Succeeded;
                }

                // Create the shared ExternalEvent router once (we are in a valid API context here).
                if (RevitContext.Router == null)
                {
                    RevitContext.Router = new RevitRequestRouter();
                }

                var settings = AppSettings.Load();

                // First read happens synchronously - we are inside Execute, a valid API context.
                var rooms = new RoomCollectorService().Collect(doc, settings);

                var worker = new RevitWorker(doc, RevitContext.Router, settings);
                var dialogs = new DialogService();
                var viewModel = new MainViewModel(rooms, worker, dialogs, settings, doc.Title);

                var window = new MainWindow(viewModel);
                RevitContext.CurrentWindow = window;
                window.Closed += (s, e) => RevitContext.CurrentWindow = null;

                // Parent the WPF window to the Revit main window so it floats above Revit but does
                // not block it (modeless).
                new WindowInteropHelper(window) { Owner = uiApp.MainWindowHandle };
                window.Show();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("Room Finisher", "An unexpected error occurred:\n\n" + ex.Message);
                return Result.Failed;
            }
        }
    }
}
