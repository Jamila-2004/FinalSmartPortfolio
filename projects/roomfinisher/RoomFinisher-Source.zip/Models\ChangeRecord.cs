namespace RoomFinisher.Models
{
    /// <summary>
    /// A single "before/after" line shown in the Review Changes window: one row per modified
    /// parameter on one room. Built by <see cref="Services.ChangeTrackingService"/>.
    /// </summary>
    public sealed class ChangeRecord
    {
        public string RoomNumber { get; set; } = string.Empty;
        public string RoomName { get; set; } = string.Empty;

        /// <summary>The display name of the parameter that changed, e.g. "Wall Finish".</summary>
        public string Parameter { get; set; } = string.Empty;

        public string OriginalValue { get; set; } = string.Empty;
        public string NewValue { get; set; } = string.Empty;
    }
}
