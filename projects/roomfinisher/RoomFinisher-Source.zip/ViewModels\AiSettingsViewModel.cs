using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using RoomFinisher.Helpers;
using RoomFinisher.Models;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// Backs the AI Settings dialog: choose the provider (Google Gemini or Anthropic Claude), paste
    /// the matching API key, and pick a model. Switching the provider swaps the key/model fields to
    /// that provider's stored values. Saving persists everything to settings.json.
    /// </summary>
    public sealed class AiSettingsViewModel : ViewModelBase
    {
        private const string Google = "Google Gemini";
        private const string Anthropic = "Anthropic Claude";

        private readonly AppSettings _settings;
        private string _selectedProvider;
        private string _apiKey;
        private string _model;

        public AiSettingsViewModel(AppSettings settings)
        {
            _settings = settings;
            Providers = new ObservableCollection<string> { Google, Anthropic };
            ModelOptions = new ObservableCollection<string>();

            _selectedProvider = settings.IsGoogle ? Google : Anthropic;
            LoadForProvider();

            SaveCommand = new RelayCommand(Save);
            CancelCommand = new RelayCommand(() => RequestClose?.Invoke(false));
        }

        public event Action<bool> RequestClose;

        public ObservableCollection<string> Providers { get; }
        public ObservableCollection<string> ModelOptions { get; }

        public string SelectedProvider
        {
            get => _selectedProvider;
            set { if (SetProperty(ref _selectedProvider, value)) LoadForProvider(); }
        }

        public string ApiKey { get => _apiKey; set => SetProperty(ref _apiKey, value); }
        public string Model { get => _model; set => SetProperty(ref _model, value); }

        public bool IsGoogle => _selectedProvider == Google;

        /// <summary>Where to get a key, shown under the field.</summary>
        public string KeyHint => IsGoogle
            ? "Get a free key at aistudio.google.com → \"Get API key\"."
            : "Get a key at console.anthropic.com → API Keys (separate from a Claude Pro plan).";

        public ICommand SaveCommand { get; }
        public ICommand CancelCommand { get; }

        // ---- helpers -------------------------------------------------------------------------
        private void LoadForProvider()
        {
            ModelOptions.Clear();
            if (IsGoogle)
            {
                ModelOptions.Add("gemini-2.0-flash");
                ModelOptions.Add("gemini-2.5-flash");
                ModelOptions.Add("gemini-2.5-pro");
                ApiKey = _settings.GoogleApiKey;
                Model = string.IsNullOrWhiteSpace(_settings.GoogleModel) ? "gemini-2.0-flash" : _settings.GoogleModel;
            }
            else
            {
                ModelOptions.Add("claude-opus-4-8");
                ModelOptions.Add("claude-sonnet-4-6");
                ModelOptions.Add("claude-haiku-4-5");
                ApiKey = _settings.AnthropicApiKey;
                Model = string.IsNullOrWhiteSpace(_settings.AiModel) ? "claude-opus-4-8" : _settings.AiModel;
            }

            RaisePropertyChanged(nameof(IsGoogle));
            RaisePropertyChanged(nameof(KeyHint));
        }

        private void Save()
        {
            if (IsGoogle)
            {
                _settings.AiProvider = "Google";
                _settings.GoogleApiKey = (ApiKey ?? string.Empty).Trim();
                _settings.GoogleModel = string.IsNullOrWhiteSpace(Model) ? "gemini-2.0-flash" : Model.Trim();
            }
            else
            {
                _settings.AiProvider = "Anthropic";
                _settings.AnthropicApiKey = (ApiKey ?? string.Empty).Trim();
                _settings.AiModel = string.IsNullOrWhiteSpace(Model) ? "claude-opus-4-8" : Model.Trim();
            }

            _settings.Save();
            RequestClose?.Invoke(true);
        }
    }
}
