using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using RoomFinisher.Helpers;
using RoomFinisher.Models;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// Backs the AI suggestions approval window. Lists each proposed change (room, parameter,
    /// current -> suggested, reason) with an Accept checkbox, plus any model notes. "Apply Selected"
    /// returns true; the caller then applies only the accepted changes to the grid (dirty-tracked),
    /// so they still go through the normal Review + commit.
    /// </summary>
    public sealed class AiSuggestionsViewModel : ViewModelBase
    {
        public AiSuggestionsViewModel(AiFinishResult result)
        {
            Changes = new ObservableCollection<AiFinishChange>(result?.Changes ?? new List<AiFinishChange>());
            Notes = new ObservableCollection<string>(result?.Notes ?? new List<string>());

            ApplyCommand = new RelayCommand(() => RequestClose?.Invoke(true), () => Changes.Count > 0);
            CancelCommand = new RelayCommand(() => RequestClose?.Invoke(false));
        }

        /// <summary>true = Apply Selected, false = Cancel.</summary>
        public event Action<bool> RequestClose;

        public ObservableCollection<AiFinishChange> Changes { get; }
        public ObservableCollection<string> Notes { get; }

        public bool HasNotes => Notes.Count > 0;

        public string Header =>
            Changes.Count == 0
                ? "The AI had no finish changes to suggest."
                : $"The AI suggested {Changes.Count} finish change{(Changes.Count == 1 ? "" : "s")}. " +
                  "Review and untick anything you don't want, then Apply.";

        /// <summary>Only the accepted changes (read by the caller after Apply).</summary>
        public IEnumerable<AiFinishChange> AcceptedChanges => Changes.Where(c => c.Accept);

        public ICommand ApplyCommand { get; }
        public ICommand CancelCommand { get; }
    }
}
