using System.Collections.Generic;

namespace RoomFinisher.Models
{
    public enum IssueSeverity
    {
        Warning,
        Error
    }

    /// <summary>A single finding from the quality-control engine (duplicate, empty, inconsistency, etc.).</summary>
    public sealed class QualityIssue
    {
        public IssueSeverity Severity { get; set; }

        /// <summary>Description of the problem, e.g. "Duplicate Room Number 101 appears 2 times.".</summary>
        public string Issue { get; set; } = string.Empty;

        /// <summary>Room number the issue relates to (may be blank for model-wide issues).</summary>
        public string RoomNumber { get; set; } = string.Empty;

        /// <summary>The field involved, when applicable (e.g. "Wall Finish").</summary>
        public string Field { get; set; } = string.Empty;

        /// <summary>Optional normalization suggestion, e.g. recommended standard spelling.</summary>
        public string Suggestion { get; set; } = string.Empty;

        /// <summary>Owning room element id (used by "Fix Selected" to jump back to the grid).</summary>
        public long ElementIdValue { get; set; }
    }

    /// <summary>The full result of a quality check, including the computed quality score.</summary>
    public sealed class QualityReport
    {
        public List<QualityIssue> Issues { get; set; } = new List<QualityIssue>();

        public int ErrorCount { get; set; }
        public int WarningCount { get; set; }

        /// <summary>Score = max(0, 100 - errors*5 - warnings*1).</summary>
        public int Score { get; set; }
    }
}
