using System.Windows;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Views
{
    /// <summary>Detailed validation dialog. "Apply Anyway" returns DialogResult true.</summary>
    public partial class ValidationWindow : Window
    {
        public ValidationWindow(ValidationViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
            viewModel.RequestClose += result =>
            {
                DialogResult = result;
                Close();
            };
        }
    }
}
