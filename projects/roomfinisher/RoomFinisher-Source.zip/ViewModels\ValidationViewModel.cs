using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using RoomFinisher.Helpers;
using RoomFinisher.Models;

namespace RoomFinisher.ViewModels
{
    /// <summary>
    /// Backs the detailed validation window shown before committing. Lists every validation finding
    /// (severity, room, message) with counts and guidance, and offers "Go Back &amp; Fix" or
    /// "Apply Anyway".
    /// </summary>
    public sealed class ValidationViewModel : ViewModelBase
    {
        public ValidationViewModel(IEnumerable<ValidationIssue> issues)
        {
            Issues = new ObservableCollection<ValidationIssue>(issues ?? Enumerable.Empty<ValidationIssue>());
            ErrorCount = Issues.Count(i => i.Severity == IssueSeverity.Error);
            WarningCount = Issues.Count(i => i.Severity == IssueSeverity.Warning);
            AffectedRooms = Issues.Select(i => i.RoomNumber)
                                  .Where(n => !string.IsNullOrWhiteSpace(n))
                                  .Distinct(StringComparer.OrdinalIgnoreCase)
                                  .Count();

            ApplyAnywayCommand = new RelayCommand(() => RequestClose?.Invoke(true));
            GoBackCommand = new RelayCommand(() => RequestClose?.Invoke(false));
        }

        /// <summary>true = Apply Anyway, false = Go Back &amp; Fix.</summary>
        public event Action<bool> RequestClose;

        public ObservableCollection<ValidationIssue> Issues { get; }

        public int ErrorCount { get; }
        public int WarningCount { get; }
        public int AffectedRooms { get; }

        public string Summary =>
            $"Errors: {ErrorCount}     Warnings: {WarningCount}     Rooms affected: {AffectedRooms}";

        public string Guidance => ErrorCount > 0
            ? "Errors (e.g. an invalid ceiling height or a missing room number) may fail to write in Revit. " +
              "You can go back and fix them now, or apply anyway - any that fail will be listed in the result summary."
            : "These are warnings only (e.g. empty finishes). Nothing will be blocked. You can apply anyway or go back and refine.";

        public ICommand ApplyAnywayCommand { get; }
        public ICommand GoBackCommand { get; }
    }
}
