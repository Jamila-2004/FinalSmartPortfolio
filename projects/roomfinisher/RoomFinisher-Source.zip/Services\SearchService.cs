using System;
using RoomFinisher.ViewModels;

namespace RoomFinisher.Services
{
    /// <summary>
    /// Builds the text-search predicate used by the main grid's CollectionViewSource. Searching is
    /// combined with level filtering by the ViewModel; this class only answers "does this room match
    /// the search text?".
    /// </summary>
    public static class SearchService
    {
        /// <summary>
        /// Returns true when the room matches the search text within the selected scopes.
        /// An empty search text always matches. When no scope is selected we search all three fields.
        /// </summary>
        public static bool Matches(RoomViewModel room, string text, bool byName, bool byNumber, bool byDepartment)
        {
            if (string.IsNullOrWhiteSpace(text)) return true;
            if (room == null) return false;

            // If the user ticked nothing, behave as "search everything".
            if (!byName && !byNumber && !byDepartment)
            {
                byName = byNumber = byDepartment = true;
            }

            text = text.Trim();

            if (byNumber && Contains(room.Number, text)) return true;
            if (byName && Contains(room.Name, text)) return true;
            if (byDepartment && Contains(room.Department, text)) return true;

            return false;
        }

        private static bool Contains(string value, string text)
        {
            return !string.IsNullOrEmpty(value) &&
                   value.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }
}
