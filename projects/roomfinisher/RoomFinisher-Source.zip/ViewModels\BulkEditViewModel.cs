using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Input;
using RoomFinisher.Helpers;
using RoomFinisher.Models;
using RoomFinisher.Services;

namespace RoomFinisher.ViewModels
{
    /// <summary>A selectable target field for the bulk-edit dialog.</summary>
    public sealed class FieldChoice
    {
        public RoomField Field { get; set; }
        public string Display { get; set; }
        public override string ToString() => Display;
    }

    /// <summary>
    /// Backs the Bulk Edit dialog: pick a target field + a value, then apply it to all selected
    /// rooms at once via <see cref="BulkEditService"/>.
    /// </summary>
    public sealed class BulkEditViewModel : ViewModelBase
    {
        private readonly FinishOptionsProvider _options;
        private readonly IList<RoomViewModel> _selectedRooms;
        private readonly BulkEditService _service;

        private FieldChoice _selectedField;
        private string _value = string.Empty;
        private ObservableCollection<string> _currentOptions = new ObservableCollection<string>();

        public BulkEditViewModel(FinishOptionsProvider options, IList<RoomViewModel> selectedRooms, BulkEditService service)
        {
            _options = options;
            _selectedRooms = selectedRooms;
            _service = service;

            TargetFields = new ObservableCollection<FieldChoice>
            {
                new FieldChoice { Field = RoomField.WallFinish,    Display = "Wall Finish" },
                new FieldChoice { Field = RoomField.FloorFinish,   Display = "Floor Finish" },
                new FieldChoice { Field = RoomField.CeilingFinish, Display = "Ceiling Finish" },
                new FieldChoice { Field = RoomField.BaseFinish,    Display = "Base Finish" },
                new FieldChoice { Field = RoomField.CeilingHeight, Display = "Ceiling Height" },
            };

            _selectedField = TargetFields[0];
            UpdateOptions();

            ApplyCommand = new RelayCommand(Apply, () => SelectedField != null);
            CancelCommand = new RelayCommand(() => RequestClose?.Invoke(false));
        }

        /// <summary>Raised to ask the hosting window to close. true = applied.</summary>
        public event Action<bool> RequestClose;

        public ObservableCollection<FieldChoice> TargetFields { get; }

        public FieldChoice SelectedField
        {
            get => _selectedField;
            set { if (SetProperty(ref _selectedField, value)) UpdateOptions(); }
        }

        /// <summary>The finish option list for the currently chosen field (empty for ceiling height).</summary>
        public ObservableCollection<string> CurrentOptions
        {
            get => _currentOptions;
            private set => SetProperty(ref _currentOptions, value);
        }

        public string Value
        {
            get => _value;
            set => SetProperty(ref _value, value);
        }

        public int SelectedCount => _selectedRooms?.Count ?? 0;

        public string Summary => $"Apply to {SelectedCount} selected room{(SelectedCount == 1 ? "" : "s")}.";

        public ICommand ApplyCommand { get; }
        public ICommand CancelCommand { get; }

        private void UpdateOptions()
        {
            var list = _options?.GetList(SelectedField?.Field ?? RoomField.WallFinish);
            CurrentOptions = list ?? new ObservableCollection<string>();
        }

        private void Apply()
        {
            if (SelectedField == null) return;
            _service.Apply(SelectedField.Field, Value, _selectedRooms);
            RequestClose?.Invoke(true);
        }
    }
}
